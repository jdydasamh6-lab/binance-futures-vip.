import { Activity, BarChart3, BellRing, Bot, CircleDollarSign, Gauge, Radio, RefreshCw, TrendingUp } from 'lucide-react';
import { Link } from 'wouter';
import {
  useGetDashboardOverview,
  useGetMarketWatchlist,
  useGetPositions,
  useGetRecentAlerts,
  useGetSignals,
} from '@workspace/api-client-react';
import { EmptyState, ErrorState, LoadingRows } from '@/components/ui-states';
import { DirectionBadge, PositionCard, SectionHeader, SignalCard, StatTile, StatusBadge, formatCurrency, formatPrice, formatTime } from '@/components/trading-ui';

export default function Dashboard() {
  const overviewQuery = useGetDashboardOverview();
  const marketQuery = useGetMarketWatchlist();
  const signalsQuery = useGetSignals();
  const positionsQuery = useGetPositions();
  const alertsQuery = useGetRecentAlerts();
  const overview = overviewQuery.data;
  const watchlist = marketQuery.data ?? [];
  const signals = signalsQuery.data ?? [];
  const positions = positionsQuery.data ?? [];
  const alerts = alertsQuery.data ?? [];

  return (
    <div className="mx-auto max-w-[1480px]">
      <section className="reveal-up relative mb-6 overflow-hidden rounded-3xl border border-border bg-card px-5 py-6 md:px-8 md:py-7">
        <div className="pointer-events-none absolute -left-20 -top-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 right-1/3 h-20 w-56 bg-accent/10 blur-3xl" />
        <div className="relative flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <div className="mb-3 flex items-center gap-2 text-[11px] font-bold text-secondary"><span className="live-pulse h-2 w-2 rounded-full bg-secondary" /> النظام يعمل ويراقب السوق</div>
            <h2 className="max-w-xl text-2xl font-bold leading-[1.35] tracking-tight md:text-3xl">صباح التداول. <span className="text-primary">القرار الواضح</span> يبدأ من هنا.</h2>
            <p className="mt-3 max-w-lg text-xs leading-6 text-muted-foreground">مراقبة Binance Futures لحظة بلحظة، مع إشارات قابلة للتفسير ومستويات خروج جاهزة للتنفيذ.</p>
          </div>
          <div className="flex shrink-0 flex-col items-start gap-2 md:items-end">
            <div className="flex items-center gap-2 rounded-xl border border-border bg-background/70 px-3 py-2 text-xs font-semibold">
              <Radio className="h-3.5 w-3.5 text-secondary" />
              السوق: <span className="text-secondary">{overview?.marketStatus || 'جاري التحقق'}</span>
            </div>
            <div className="font-mono-value text-[10px] text-muted-foreground">
              آخر فحص {overview?.lastScanAt ? formatTime(overview.lastScanAt) : '—'}
            </div>
          </div>
        </div>
      </section>

      {overviewQuery.isError ? (
        <div className="mb-6"><ErrorState onRetry={() => overviewQuery.refetch()} /></div>
      ) : (
        <section className="reveal-up reveal-up-delay-1 mb-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatTile label="إشارات نشطة" value={overview ? String(overview.activeSignals) : '—'} detail="الآن" tone="alert" icon={<Activity className="h-4 w-4" />} />
          <StatTile label="نسبة النجاح" value={overview ? `${overview.winRate.toFixed(1)}%` : '—'} detail="هذا الأسبوع" tone="positive" icon={<TrendingUp className="h-4 w-4" />} />
          <StatTile label="صافي الأداء" value={overview ? `${overview.totalPnl >= 0 ? '+' : ''}${formatCurrency(overview.totalPnl)}` : '—'} detail="USDT" tone={overview && overview.totalPnl >= 0 ? 'positive' : 'alert'} icon={<CircleDollarSign className="h-4 w-4" />} />
          <StatTile label="اتصال تيليجرام" value={overview?.telegramStatus || '—'} detail="تنبيهات فورية" icon={<BellRing className="h-4 w-4" />} />
        </section>
      )}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(360px,.85fr)]">
        <section className="reveal-up reveal-up-delay-2 min-w-0">
          <SectionHeader
            eyebrow="MARKET WATCH"
              title="رادار السوق"
              action={<span className="flex items-center gap-1.5 text-[10px] font-semibold text-muted-foreground"><Gauge className="h-3.5 w-3.5 text-primary" /> 30 عملة رئيسية · ترتيب حسب قوة الإشارة</span>}
          />
          <div className="overflow-hidden rounded-2xl border border-border bg-card">
            {marketQuery.isLoading ? <div className="p-4"><LoadingRows count={4} /></div> : marketQuery.isError ? <div className="p-4"><ErrorState onRetry={() => marketQuery.refetch()} /></div> : watchlist.length === 0 ? <EmptyState title="لا توجد أزواج للمراقبة" detail="ستظهر الأزواج عند وصول بيانات السوق." /> : (
              <>
                <div className="hidden grid-cols-[1.3fr_1fr_1fr_1fr_1fr] gap-4 border-b border-border px-5 py-3 text-[10px] font-bold text-muted-foreground md:grid">
                  <span>الزوج</span><span>السعر</span><span>24 ساعة</span><span>الإطار</span><span className="text-left">القوة</span>
                </div>
                <div className="divide-y divide-border/70">
                  {watchlist.map((pair) => (
                    <div key={pair.symbol} className="grid grid-cols-2 gap-y-3 px-5 py-4 transition-colors hover:bg-muted/35 md:grid-cols-[1.3fr_1fr_1fr_1fr_1fr] md:items-center md:gap-4" data-testid={`row-market-${pair.symbol}`}>
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted text-[9px] font-bold text-muted-foreground">{pair.symbol.replace('USDT', '')}</div>
                        <div><div className="font-mono-value text-xs font-bold">{pair.symbol}</div><div className="mt-0.5 text-[10px] text-muted-foreground">{pair.trend}</div></div>
                      </div>
                      <div><div className="text-[10px] text-muted-foreground md:hidden">السعر</div><div className="mt-0.5 font-mono-value text-xs font-bold md:mt-0">{formatPrice(pair.price)}</div></div>
                      <div><div className="text-[10px] text-muted-foreground md:hidden">التغير</div><div className={`mt-0.5 font-mono-value text-xs font-bold md:mt-0 ${pair.change24h >= 0 ? 'text-secondary' : 'text-destructive'}`}>{pair.change24h >= 0 ? '+' : ''}{pair.change24h.toFixed(2)}%</div></div>
                      <div><div className="text-[10px] text-muted-foreground md:hidden">الإطار</div><div className="mt-0.5 font-mono-value text-xs md:mt-0">{pair.timeframe}</div></div>
                      <div className="text-left"><div className="mb-1 flex items-center justify-end gap-2"><span className="font-mono-value text-xs font-bold">{pair.score.toFixed(1)}</span><span className="text-[10px] text-muted-foreground">/ 100</span></div><div className="ml-auto h-1.5 w-20 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, Math.max(0, pair.score))}%` }} /></div></div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </section>

        <section className="reveal-up reveal-up-delay-2">
          <SectionHeader eyebrow="SIGNAL FEED" title="آخر الإشارات" action={<Link href="/signals" data-testid="link-dashboard-signals" className="text-[11px] font-bold text-primary no-underline">عرض الكل</Link>} />
          {signalsQuery.isLoading ? <LoadingRows count={2} /> : signalsQuery.isError ? <ErrorState onRetry={() => signalsQuery.refetch()} /> : signals.length === 0 ? <EmptyState title="لا توجد إشارات بعد" detail="استخدم مولد الإشارة لتحليل زوج الآن." action={<Link href="/signals" data-testid="link-empty-generate" className="mt-4 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground no-underline">تحليل زوج</Link>} /> : (
            <div className="space-y-3">{signals.slice(0, 3).map((signal) => <SignalCard key={signal.id} signal={signal} compact />)}</div>
          )}
        </section>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(320px,.7fr)]">
        <section className="reveal-up reveal-up-delay-3">
          <SectionHeader eyebrow="POSITION MONITOR" title="مراقبة المراكز" action={<Link href="/positions" data-testid="link-dashboard-positions" className="text-[11px] font-bold text-primary no-underline">كل المراكز</Link>} />
          {positionsQuery.isLoading ? <LoadingRows count={2} /> : positionsQuery.isError ? <ErrorState onRetry={() => positionsQuery.refetch()} /> : positions.length === 0 ? <EmptyState title="لا توجد مراكز مفتوحة" detail="عند تفعيل إشارة، ستظهر مستوياتها وتقدمها هنا." /> : <div className="grid gap-3 md:grid-cols-2">{positions.slice(0, 2).map((position) => <PositionCard key={position.id} position={position} />)}</div>}
        </section>
        <section className="reveal-up reveal-up-delay-3">
          <SectionHeader eyebrow="ALERT LOG" title="سجل التنبيهات" action={<span className="font-mono-value text-[10px] text-muted-foreground">{alerts.length} حدث</span>} />
          {alertsQuery.isLoading ? <LoadingRows count={3} /> : alertsQuery.isError ? <ErrorState onRetry={() => alertsQuery.refetch()} /> : alerts.length === 0 ? <EmptyState title="السجل فارغ" detail="ستظهر هنا تنبيهات الإشارات وتحديثات المراكز." /> : (
            <div className="divide-y divide-border/70 overflow-hidden rounded-2xl border border-border bg-card">
              {alerts.slice(0, 5).map((alert) => <div key={alert.id} className="flex items-start gap-3 px-4 py-3.5" data-testid={`alert-event-${alert.id}`}><div className={`mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${alert.type.toLowerCase().includes('signal') ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'}`}><BellRing className="h-3.5 w-3.5" /></div><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><div className="truncate text-xs font-bold">{alert.title}</div><StatusBadge status={alert.status} /></div><div className="mt-1 truncate text-[10px] text-muted-foreground">{alert.detail}</div><div className="mt-1 font-mono-value text-[9px] text-muted-foreground/70">{formatTime(alert.timestamp)}</div></div></div>)}
            </div>
          )}
        </section>
      </div>

      {!overviewQuery.isLoading && overview && (
        <div className="mt-8 flex items-center justify-between rounded-xl border border-border bg-card/65 px-4 py-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-2"><RefreshCw className="h-3 w-3" /> يتم تحديث البيانات تلقائياً من Binance Futures</span>
          <span className="font-mono-value" data-testid="text-last-scan">{overview.lastScanAt ? formatTime(overview.lastScanAt) : '—'}</span>
        </div>
      )}
    </div>
  );
}