import { useEffect, useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, CheckCircle2, Loader2, ScanSearch, SlidersHorizontal } from 'lucide-react';
import { Link } from 'wouter';
import {
  getGetDashboardOverviewQueryKey,
  getGetSignalsQueryKey,
  useGenerateSignal,
  useGetMarketWatchlist,
  useGetSignals,
} from '@workspace/api-client-react';
import { EmptyState, ErrorState, LoadingRows } from '@/components/ui-states';
import { SectionHeader, SignalCard } from '@/components/trading-ui';

export default function Signals() {
  const queryClient = useQueryClient();
  const signalsQuery = useGetSignals();
  const marketQuery = useGetMarketWatchlist();
  const generateSignal = useGenerateSignal();
  const signals = signalsQuery.data ?? [];
  const pairs = useMemo(() => marketQuery.data ?? [], [marketQuery.data]);
  const [symbol, setSymbol] = useState('');
  const [timeframe, setTimeframe] = useState('15m');

  useEffect(() => {
    if (!symbol && pairs.length > 0) setSymbol(pairs[0].symbol);
  }, [pairs, symbol]);

  function handleGenerate() {
    if (!symbol) return;
    generateSignal.mutate(
      { data: { symbol, timeframe } },
      {
        onSuccess: async () => {
          await Promise.all([
            queryClient.invalidateQueries({ queryKey: getGetSignalsQueryKey() }),
            queryClient.invalidateQueries({ queryKey: getGetDashboardOverviewQueryKey() }),
          ]);
        },
      },
    );
  }

  return (
    <div className="mx-auto max-w-[1480px]">
      <div className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.16em] text-primary"><ScanSearch className="h-3.5 w-3.5" /> SIGNAL GENERATOR</div>
          <h2 className="text-2xl font-bold tracking-tight">إشارات قابلة للتنفيذ، لا ضوضاء.</h2>
          <p className="mt-2 text-xs leading-6 text-muted-foreground">اختر الزوج والإطار. سيقوم البوت بتحليل الزخم، السيولة، والاتجاه ثم يشرح سبب القرار.</p>
        </div>
        <Link href="/" data-testid="link-signals-back" className="flex items-center gap-2 text-xs font-bold text-muted-foreground no-underline hover:text-foreground"><ArrowLeft className="h-4 w-4" /> العودة للمركز</Link>
      </div>

      <section className="mb-8 grid gap-5 lg:grid-cols-[minmax(0,.75fr)_minmax(0,1.25fr)]">
        <div className="rounded-3xl border border-primary/25 bg-card p-5 shadow-sm md:p-6">
          <div className="flex items-center justify-between"><div><div className="text-[10px] font-bold uppercase tracking-[0.16em] text-primary">NEW ANALYSIS</div><h3 className="mt-2 text-lg font-bold">توليد إشارة VIP</h3></div><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><SlidersHorizontal className="h-5 w-5" /></div></div>
          <div className="mt-7 space-y-5">
            <label className="block"><span className="mb-2 block text-xs font-bold">زوج التداول</span><select value={symbol} onChange={(event) => setSymbol(event.target.value)} data-testid="select-signal-symbol" className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm font-mono-value outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-primary/15"><option value="" disabled>اختر زوجاً</option>{pairs.map((pair) => <option key={pair.symbol} value={pair.symbol}>{pair.symbol}</option>)}</select></label>
            <label className="block"><span className="mb-2 block text-xs font-bold">الإطار الزمني</span><div className="grid grid-cols-4 gap-2">{['5m', '15m', '1h', '4h'].map((option) => <button key={option} type="button" onClick={() => setTimeframe(option)} data-testid={`button-timeframe-${option}`} className={`rounded-xl border py-2.5 font-mono-value text-xs font-bold transition-colors ${timeframe === option ? 'border-primary bg-primary text-primary-foreground' : 'border-border bg-background hover:bg-muted'}`}>{option}</button>)}</div></label>
            {generateSignal.isError && <div className="rounded-xl border border-destructive/20 bg-destructive/5 p-3 text-xs font-semibold text-destructive">تعذر توليد الإشارة. حاول مرة أخرى.</div>}
            {generateSignal.isSuccess && <div className="flex items-center gap-2 rounded-xl border border-secondary/20 bg-secondary/5 p-3 text-xs font-semibold text-secondary"><CheckCircle2 className="h-4 w-4" /> تم تحديث قائمة الإشارات</div>}
            <button type="button" onClick={handleGenerate} disabled={!symbol || generateSignal.isPending} data-testid="button-generate-signal" className="flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/15 transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-50">
              {generateSignal.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> جارٍ تحليل السوق</> : <><ScanSearch className="h-4 w-4" /> تحليل وتوليد الإشارة</>}
            </button>
          </div>
          <div className="mt-5 border-t border-border/70 pt-4 text-[10px] leading-5 text-muted-foreground">النتيجة ليست توصية استثمارية. راجع مستويات الدخول ووقف الخسارة قبل التنفيذ.</div>
        </div>

        <div>
          <SectionHeader eyebrow="WATCHLIST CONTEXT" title="الأزواج المرشحة الآن" />
          {marketQuery.isLoading ? <LoadingRows count={3} /> : marketQuery.isError ? <ErrorState onRetry={() => marketQuery.refetch()} /> : pairs.length === 0 ? <EmptyState title="لا توجد بيانات سوق" detail="لا يمكن اختيار زوج قبل وصول قائمة المراقبة." /> : <div className="grid gap-3 sm:grid-cols-2">{pairs.slice(0, 6).map((pair) => <button key={pair.symbol} type="button" onClick={() => setSymbol(pair.symbol)} data-testid={`button-pair-${pair.symbol}`} className={`signal-card flex items-center justify-between rounded-2xl border bg-card p-4 text-right ${symbol === pair.symbol ? 'border-primary ring-2 ring-primary/10' : 'border-border'}`}><div><div className="font-mono-value text-sm font-bold">{pair.symbol}</div><div className="mt-1 text-[10px] text-muted-foreground">{pair.trend} · {pair.timeframe}</div></div><div className="text-left"><div className={`font-mono-value text-sm font-bold ${pair.change24h >= 0 ? 'text-secondary' : 'text-destructive'}`}>{pair.change24h >= 0 ? '+' : ''}{pair.change24h.toFixed(2)}%</div><div className="mt-1 text-[10px] text-muted-foreground">قوة {pair.score.toFixed(1)}</div></div></button>)}</div>}
        </div>
      </section>

      <section>
        <SectionHeader eyebrow="SIGNAL ARCHIVE" title="الإشارات الأخيرة" action={<span className="font-mono-value text-[10px] text-muted-foreground">{signals.length} إشارة</span>} />
        {signalsQuery.isLoading ? <LoadingRows count={4} /> : signalsQuery.isError ? <ErrorState onRetry={() => signalsQuery.refetch()} /> : signals.length === 0 ? <EmptyState title="لم يتم توليد إشارات" detail="ابدأ بتحليل أحد الأزواج المرشحة من الأعلى." /> : <div className="grid gap-4 lg:grid-cols-2">{signals.map((signal) => <SignalCard key={signal.id} signal={signal} />)}</div>}
      </section>
    </div>
  );
}