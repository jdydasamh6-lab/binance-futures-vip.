import { ArrowLeft, BriefcaseBusiness, CircleDollarSign, Layers3 } from 'lucide-react';
import { Link } from 'wouter';
import { useGetPositions } from '@workspace/api-client-react';
import { EmptyState, ErrorState, LoadingRows } from '@/components/ui-states';
import { PositionCard, SectionHeader, StatTile } from '@/components/trading-ui';

export default function Positions() {
  const positionsQuery = useGetPositions();
  const positions = positionsQuery.data ?? [];
  const totalPnl = positions.reduce((sum, position) => sum + position.pnl, 0);
  const avgProgress = positions.length ? positions.reduce((sum, position) => sum + position.progress, 0) / positions.length : 0;

  return (
    <div className="mx-auto max-w-[1480px]">
      <div className="mb-7 flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div><div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.16em] text-secondary"><BriefcaseBusiness className="h-3.5 w-3.5" /> POSITION CONTROL</div><h2 className="text-2xl font-bold tracking-tight">المراكز تحت السيطرة.</h2><p className="mt-2 text-xs leading-6 text-muted-foreground">تابع تحرك السعر مقابل الدخول، وأدر تقدم TP / BE / SL من شاشة واحدة.</p></div>
        <Link href="/signals" data-testid="link-positions-signal" className="flex items-center gap-2 text-xs font-bold text-primary no-underline"><span>افتح مولد الإشارة</span><ArrowLeft className="h-4 w-4" /></Link>
      </div>

      <section className="mb-8 grid grid-cols-2 gap-3 lg:grid-cols-3">
        <StatTile label="مراكز مفتوحة" value={String(positions.length)} detail="نشط الآن" tone="alert" icon={<Layers3 className="h-4 w-4" />} />
        <StatTile label="إجمالي الأداء" value={`${totalPnl >= 0 ? '+' : ''}${totalPnl.toFixed(2)}`} detail="USDT" tone={totalPnl >= 0 ? 'positive' : 'alert'} icon={<CircleDollarSign className="h-4 w-4" />} />
        <div className="col-span-2 lg:col-span-1"><StatTile label="متوسط التقدم" value={`${avgProgress.toFixed(0)}%`} detail="مقابل الأهداف" icon={<Layers3 className="h-4 w-4" />} /></div>
      </section>

      <section>
        <SectionHeader eyebrow="OPEN POSITIONS" title="المراكز الحالية" action={<span className="text-[10px] text-muted-foreground">تحديث تلقائي</span>} />
        {positionsQuery.isLoading ? <LoadingRows count={3} /> : positionsQuery.isError ? <ErrorState onRetry={() => positionsQuery.refetch()} /> : positions.length === 0 ? <EmptyState title="لا توجد مراكز مفتوحة" detail="ستظهر هنا المراكز المرتبطة بإشاراتك النشطة فور تنفيذها." action={<Link href="/signals" data-testid="link-empty-position-signal" className="mt-4 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground no-underline">توليد إشارة</Link>} /> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{positions.map((position) => <PositionCard key={position.id} position={position} />)}</div>}
      </section>
    </div>
  );
}