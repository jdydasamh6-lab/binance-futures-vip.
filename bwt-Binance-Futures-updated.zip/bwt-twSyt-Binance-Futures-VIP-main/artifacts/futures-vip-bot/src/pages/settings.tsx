import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { Check, Loader2, Save, Settings2, ShieldCheck, SlidersHorizontal } from 'lucide-react';
import {
  getGetBotSettingsQueryKey,
  useGetBotSettings,
  useUpdateBotSettings,
} from '@workspace/api-client-react';
import { ErrorState, LoadingRows } from '@/components/ui-states';
import { SectionHeader, StatusBadge } from '@/components/trading-ui';

export default function Settings() {
  const queryClient = useQueryClient();
  const settingsQuery = useGetBotSettings();
  const updateSettings = useUpdateBotSettings();
  const settings = settingsQuery.data;
  const [scanInterval, setScanInterval] = useState('');
  const [minConfidence, setMinConfidence] = useState(70);
  const [defaultLeverage, setDefaultLeverage] = useState('');
  const [autoBreakEven, setAutoBreakEven] = useState(false);

  useEffect(() => {
    if (!settings) return;
    setScanInterval(settings.scanInterval);
    setMinConfidence(settings.minConfidence);
    setDefaultLeverage(settings.defaultLeverage);
    setAutoBreakEven(settings.autoBreakEven);
  }, [settings]);

  function handleSave() {
    updateSettings.mutate(
      { data: { scanInterval, minConfidence: Number(minConfidence), defaultLeverage, autoBreakEven } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetBotSettingsQueryKey() }) },
    );
  }

  return (
    <div className="mx-auto max-w-[1100px]">
      <div className="mb-7"><div className="mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.16em] text-primary"><Settings2 className="h-3.5 w-3.5" /> BOT CONFIGURATION</div><h2 className="text-2xl font-bold tracking-tight">إعدادات التشغيل.</h2><p className="mt-2 text-xs leading-6 text-muted-foreground">اضبط حساسية الماسح وسلوك إدارة المركز. التغيير يُطبّق على دورة الفحص التالية.</p></div>

      {settingsQuery.isLoading ? <LoadingRows count={4} /> : settingsQuery.isError ? <ErrorState onRetry={() => settingsQuery.refetch()} /> : (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
          <section className="rounded-3xl border border-border bg-card p-5 md:p-7">
            <SectionHeader eyebrow="SCAN ENGINE" title="محرك الإشارات" />
            <div className="space-y-6">
              <label className="block"><span className="mb-2 block text-xs font-bold">فاصل الفحص</span><span className="mb-2 block text-[10px] text-muted-foreground">كم مرة يبحث البوت عن فرص جديدة</span><select value={scanInterval} onChange={(event) => setScanInterval(event.target.value)} data-testid="select-scan-interval" className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/15"><option value="1m">كل دقيقة</option><option value="5m">كل 5 دقائق</option><option value="15m">كل 15 دقيقة</option><option value="30m">كل 30 دقيقة</option><option value="1h">كل ساعة</option></select></label>
              <div><div className="mb-2 flex items-center justify-between"><span className="text-xs font-bold">الحد الأدنى للثقة</span><span className="font-mono-value text-sm font-bold text-primary">{minConfidence}%</span></div><div className="mb-3 text-[10px] text-muted-foreground">لا ترسل إشارات أقل من مستوى الثقة المختار</div><input type="range" min="50" max="95" step="1" value={minConfidence} onChange={(event) => setMinConfidence(Number(event.target.value))} data-testid="input-min-confidence" className="h-1.5 w-full cursor-pointer accent-[hsl(var(--primary))]" /><div className="mt-2 flex justify-between text-[10px] font-mono-value text-muted-foreground"><span>50%</span><span>95%</span></div></div>
              <label className="block"><span className="mb-2 block text-xs font-bold">الرافعة الافتراضية</span><span className="mb-2 block text-[10px] text-muted-foreground">تُستخدم عند توليد إشارة جديدة</span><select value={defaultLeverage} onChange={(event) => setDefaultLeverage(event.target.value)} data-testid="select-default-leverage" className="w-full rounded-xl border border-input bg-background px-3 py-3 text-sm font-mono-value outline-none focus:border-primary focus:ring-2 focus:ring-primary/15"><option value="3x">3x</option><option value="5x">5x</option><option value="10x">10x</option><option value="20x">20x</option></select></label>
              <div className="flex items-center justify-between gap-4 rounded-2xl border border-border bg-background/50 p-4"><div><div className="text-xs font-bold">نقل وقف الخسارة إلى نقطة التعادل</div><div className="mt-1 text-[10px] leading-5 text-muted-foreground">بعد تحقق الهدف الأول، يحمي البوت رأس المال تلقائياً.</div></div><button type="button" role="switch" aria-checked={autoBreakEven} onClick={() => setAutoBreakEven((current) => !current)} data-testid="button-toggle-break-even" className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${autoBreakEven ? 'bg-secondary' : 'bg-muted'}`}><span className={`absolute top-1 h-5 w-5 rounded-full bg-card shadow-sm transition-transform ${autoBreakEven ? 'translate-x-1' : 'translate-x-6'}`} /></button></div>
            </div>
            {updateSettings.isError && <div className="mt-5 rounded-xl border border-destructive/20 bg-destructive/5 p-3 text-xs font-semibold text-destructive">تعذر حفظ الإعدادات. حاول مرة أخرى.</div>}
            {updateSettings.isSuccess && <div className="mt-5 flex items-center gap-2 rounded-xl border border-secondary/20 bg-secondary/5 p-3 text-xs font-semibold text-secondary"><Check className="h-4 w-4" /> تم حفظ إعدادات البوت</div>}
            <button type="button" onClick={handleSave} disabled={updateSettings.isPending} data-testid="button-save-settings" className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-bold text-primary-foreground shadow-lg shadow-primary/15 transition-transform hover:-translate-y-0.5 disabled:opacity-50">{updateSettings.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> جارٍ الحفظ</> : <><Save className="h-4 w-4" /> حفظ الإعدادات</>}</button>
          </section>

          <aside className="space-y-4">
            <section className="rounded-3xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-secondary/10 text-secondary"><ShieldCheck className="h-5 w-5" /></div><div><div className="text-sm font-bold">حالة الاتصال</div><div className="mt-1 text-[10px] text-muted-foreground">قناة التنبيهات</div></div></div>
              <div className="flex items-center justify-between border-t border-border/70 pt-4"><span className="text-xs font-semibold">Telegram</span><StatusBadge status={settings?.telegramStatus || 'غير متصل'} /></div>
            </section>
            <section className="rounded-3xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary"><SlidersHorizontal className="h-5 w-5" /></div><div><div className="text-sm font-bold">ملخص التكوين</div><div className="mt-1 text-[10px] text-muted-foreground">القيم الحالية</div></div></div>
              <div className="space-y-3 text-xs"><div className="flex justify-between"><span className="text-muted-foreground">الفحص</span><span className="font-mono-value font-bold">{scanInterval || '—'}</span></div><div className="flex justify-between"><span className="text-muted-foreground">الثقة</span><span className="font-mono-value font-bold">{minConfidence}%</span></div><div className="flex justify-between"><span className="text-muted-foreground">الرافعة</span><span className="font-mono-value font-bold">{defaultLeverage || '—'}</span></div><div className="flex justify-between"><span className="text-muted-foreground">التعادل التلقائي</span><span className={autoBreakEven ? 'font-bold text-secondary' : 'font-semibold text-muted-foreground'}>{autoBreakEven ? 'مفعل' : 'متوقف'}</span></div></div>
            </section>
          </aside>
        </div>
      )}
    </div>
  );
}