import { AlertTriangle, Inbox, RefreshCw } from 'lucide-react';
import type { ReactNode } from 'react';

export function LoadingRows({ count = 3 }: { count?: number }) {
  return (
    <div className="space-y-3" data-testid="loading-state">
      {Array.from({ length: count }).map((_, index) => (
        <div key={index} className="flex animate-pulse items-center gap-4 rounded-xl border border-border bg-card px-4 py-4">
          <div className="h-9 w-9 rounded-lg bg-muted" />
          <div className="flex-1 space-y-2">
            <div className="h-3 w-32 rounded bg-muted" />
            <div className="h-2.5 w-48 rounded bg-muted/70" />
          </div>
          <div className="h-3 w-16 rounded bg-muted" />
        </div>
      ))}
    </div>
  );
}

export function ErrorState({ onRetry, label = 'تعذّر تحميل البيانات' }: { onRetry?: () => void; label?: string }) {
  return (
    <div className="flex min-h-[180px] flex-col items-center justify-center rounded-2xl border border-destructive/20 bg-destructive/5 p-6 text-center" data-testid="error-state">
      <AlertTriangle className="mb-3 h-6 w-6 text-destructive" />
      <div className="text-sm font-bold">{label}</div>
      <div className="mt-1 text-xs text-muted-foreground">تحقق من الاتصال ثم حاول مرة أخرى.</div>
      {onRetry && (
        <button type="button" onClick={onRetry} data-testid="button-retry" className="mt-4 flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-xs font-bold transition-colors hover:bg-muted">
          <RefreshCw className="h-3.5 w-3.5" /> إعادة المحاولة
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title, detail, action }: { title: string; detail: string; action?: ReactNode }) {
  return (
    <div className="flex min-h-[180px] flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-card/50 p-6 text-center" data-testid="empty-state">
      <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-muted text-muted-foreground">
        <Inbox className="h-5 w-5" />
      </div>
      <div className="text-sm font-bold">{title}</div>
      <div className="mt-1 max-w-xs text-xs leading-5 text-muted-foreground">{detail}</div>
      {action}
    </div>
  );
}