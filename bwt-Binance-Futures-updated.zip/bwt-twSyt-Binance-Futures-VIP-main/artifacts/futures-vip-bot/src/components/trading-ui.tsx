import { ArrowDownLeft, ArrowUpRight, BrainCircuit, Check, Clock3, Target } from 'lucide-react';
import type { ReactNode } from 'react';
import type { Position, TradingSignal } from '@workspace/api-client-react';

export function formatPrice(value: number) {
  return new Intl.NumberFormat('en-US', { minimumFractionDigits: value < 1 ? 4 : 2, maximumFractionDigits: value < 1 ? 6 : 2 }).format(value);
}

export function formatCurrency(value: number) {
  return new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
}

export function formatTime(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('ar-SA', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' }).format(date);
}

export function directionIsLong(direction: string) {
  return direction.toLowerCase().includes('long') || direction.toLowerCase().includes('شراء');
}

export function DirectionBadge({ direction }: { direction: string }) {
  const long = directionIsLong(direction);
  return (
    <span className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-bold ${long ? 'bg-secondary/10 text-secondary' : 'bg-destructive/10 text-destructive'}`}>
      {long ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownLeft className="h-3 w-3" />}
      {long ? 'LONG' : 'SHORT'}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const normalized = status.toLowerCase();
  const isPositive = normalized.includes('active') || normalized.includes('open') || normalized.includes('sent') || normalized.includes('filled') || normalized.includes('ناجح') || normalized.includes('نشط');
  const isWarning = normalized.includes('pending') || normalized.includes('wait') || normalized.includes('معلّق');
  return (
    <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold ${isPositive ? 'text-secondary' : isWarning ? 'text-accent-foreground' : 'text-muted-foreground'}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${isPositive ? 'bg-secondary' : isWarning ? 'bg-accent' : 'bg-muted-foreground/50'}`} />
      {status || 'غير محدد'}
    </span>
  );
}

export function StatTile({ label, value, detail, tone = 'default', icon }: { label: string; value: string; detail?: string; tone?: 'default' | 'positive' | 'alert'; icon?: ReactNode }) {
  return (
    <div className="signal-card relative overflow-hidden rounded-2xl border border-border bg-card p-5" data-testid={`stat-${label}`}>
      <div className={`absolute right-0 top-0 h-full w-1 ${tone === 'positive' ? 'bg-secondary' : tone === 'alert' ? 'bg-primary' : 'bg-border'}`} />
      <div className="flex items-start justify-between gap-2">
        <div className="text-xs font-semibold text-muted-foreground">{label}</div>
        {icon && <div className={`rounded-lg p-2 ${tone === 'positive' ? 'bg-secondary/10 text-secondary' : tone === 'alert' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>{icon}</div>}
      </div>
      <div className="mt-4 flex items-baseline gap-2">
        <span className="font-mono-value text-2xl font-bold tracking-tight">{value}</span>
        {detail && <span className="text-[11px] font-semibold text-secondary">{detail}</span>}
      </div>
    </div>
  );
}

export function SectionHeader({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-primary">{eyebrow}</div>}
        <h2 className="text-base font-bold tracking-tight">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function SignalCard({ signal, compact = false }: { signal: TradingSignal; compact?: boolean }) {
  const long = directionIsLong(signal.direction);
  return (
    <article className={`signal-card rounded-2xl border border-border bg-card ${compact ? 'p-4' : 'p-5'}`} data-testid={`card-signal-${signal.id}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`flex h-10 w-10 items-center justify-center rounded-xl text-xs font-bold ${long ? 'bg-secondary/10 text-secondary' : 'bg-destructive/10 text-destructive'}`}>
            {signal.symbol.replace('USDT', '').replace('/', '')}
          </div>
          <div>
            <div className="font-mono-value text-sm font-bold">{signal.symbol}</div>
            <div className="mt-0.5 flex items-center gap-2 text-[10px] text-muted-foreground"><Clock3 className="h-3 w-3" /> {formatTime(signal.createdAt)} · {signal.timeframe}</div>
          </div>
        </div>
        <DirectionBadge direction={signal.direction} />
      </div>
      <div className={`mt-5 grid ${compact ? 'grid-cols-3' : 'grid-cols-4'} gap-2`}>
        <div><div className="text-[10px] text-muted-foreground">الدخول</div><div className="mt-1 font-mono-value text-xs font-bold">{formatPrice(signal.entryPrice)}</div></div>
        <div><div className="text-[10px] text-muted-foreground">وقف الخسارة</div><div className="mt-1 font-mono-value text-xs font-bold text-destructive">{formatPrice(signal.stopLoss)}</div></div>
        {!compact && <div><div className="text-[10px] text-muted-foreground">الرافعة</div><div className="mt-1 font-mono-value text-xs font-bold">{signal.leverage}</div></div>}
        <div><div className="text-[10px] text-muted-foreground">الثقة</div><div className="mt-1 font-mono-value text-xs font-bold text-secondary">{signal.confidence.toFixed(1)}%</div></div>
      </div>
      {!compact && (
        <>
          <div className="mt-4 flex items-center gap-2 rounded-xl bg-muted/65 px-3 py-2.5 text-xs leading-5 text-muted-foreground">
            <BrainCircuit className="h-4 w-4 shrink-0 text-primary" />
            <span>{signal.reason}</span>
          </div>
          <TargetProgress targets={signal.targets} />
        </>
      )}
      <div className="mt-4 flex items-center justify-between border-t border-border/70 pt-3">
        <StatusBadge status={signal.status} />
        <span className="font-mono-value text-[10px] text-muted-foreground">{signal.id}</span>
      </div>
    </article>
  );
}

export function TargetProgress({ targets }: { targets: TradingSignal['targets'] }) {
  return (
    <div className="mt-4 grid grid-cols-3 gap-2">
      {targets.slice(0, 3).map((target) => {
        const done = target.status.toLowerCase().includes('hit') || target.status.toLowerCase().includes('done') || target.status.toLowerCase().includes('تم');
        return (
          <div key={target.label} className={`rounded-xl border p-2.5 ${done ? 'border-secondary/25 bg-secondary/5' : 'border-border bg-background/50'}`}>
            <div className="flex items-center justify-between text-[10px] font-bold text-muted-foreground"><span>{target.label}</span>{done && <Check className="h-3 w-3 text-secondary" />}</div>
            <div className="mt-1 font-mono-value text-[11px] font-bold">{formatPrice(target.price)}</div>
            <div className={`mt-1 text-[10px] font-semibold ${done ? 'text-secondary' : 'text-muted-foreground'}`}>{target.percent > 0 ? '+' : ''}{target.percent.toFixed(2)}%</div>
          </div>
        );
      })}
    </div>
  );
}

export function PositionCard({ position }: { position: Position }) {
  const positive = position.pnl >= 0;
  return (
    <article className="signal-card rounded-2xl border border-border bg-card p-4" data-testid={`card-position-${position.id}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl text-[10px] font-bold ${positive ? 'bg-secondary/10 text-secondary' : 'bg-destructive/10 text-destructive'}`}>{position.symbol.replace('USDT', '')}</div>
          <div><div className="font-mono-value text-sm font-bold">{position.symbol}</div><div className="mt-0.5 text-[10px] text-muted-foreground">{position.leverage} · حجم {position.size}</div></div>
        </div>
        <DirectionBadge direction={position.direction} />
      </div>
      <div className="mt-5 flex items-end justify-between">
        <div><div className="text-[10px] text-muted-foreground">الربح / الخسارة</div><div className={`mt-1 font-mono-value text-xl font-bold ${positive ? 'text-secondary' : 'text-destructive'}`}>{positive ? '+' : ''}{formatCurrency(position.pnl)}</div></div>
        <div className={`font-mono-value text-sm font-bold ${positive ? 'text-secondary' : 'text-destructive'}`}>{positive ? '+' : ''}{position.pnlPercent.toFixed(2)}%</div>
      </div>
      <div className="mt-4">
        <div className="mb-2 flex justify-between text-[10px] font-semibold text-muted-foreground"><span>تقدم المركز</span><span className="font-mono-value">{position.progress.toFixed(0)}%</span></div>
        <div className="h-2 overflow-hidden rounded-full bg-muted"><div className={`h-full rounded-full ${positive ? 'bg-secondary' : 'bg-primary'}`} style={{ width: `${Math.min(100, Math.max(0, position.progress))}%` }} /></div>
      </div>
      <div className="mt-3 grid grid-cols-5 gap-1">
        {['TP1', 'TP2', 'TP3', 'BE', 'SL'].map((step, index) => {
          const threshold = index === 0 ? 25 : index === 1 ? 50 : index === 2 ? 75 : index === 3 ? 90 : 101;
          const reached = position.progress >= threshold;
          return <div key={step} className={`rounded-md py-1.5 text-center font-mono-value text-[9px] font-bold ${reached ? 'bg-secondary/12 text-secondary' : 'bg-muted text-muted-foreground/60'}`}>{step}</div>;
        })}
      </div>
      <div className="mt-4 grid grid-cols-2 gap-3 border-t border-border/70 pt-3 text-[10px]">
        <div><span className="text-muted-foreground">سعر الدخول</span><div className="mt-1 font-mono-value font-bold">{formatPrice(position.entry)}</div></div>
        <div><span className="text-muted-foreground">السعر الحالي</span><div className="mt-1 font-mono-value font-bold">{formatPrice(position.markPrice)}</div></div>
      </div>
    </article>
  );
}