import { Activity, Bot, ChevronLeft, LayoutDashboard, ListFilter, Settings2, ShieldCheck, WalletCards } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Link, useLocation } from 'wouter';
import type { ReactNode } from 'react';

const navItems: Array<{ href: string; label: string; icon: LucideIcon }> = [
  { href: '/', label: 'نظرة عامة', icon: LayoutDashboard },
  { href: '/signals', label: 'الإشارات', icon: ListFilter },
  { href: '/positions', label: 'المراكز', icon: WalletCards },
  { href: '/settings', label: 'إعدادات البوت', icon: Settings2 },
];

const pageTitles: Record<string, string> = {
  '/': 'مركز القيادة',
  '/signals': 'الإشارات الحية',
  '/positions': 'المراكز المفتوحة',
  '/settings': 'إعدادات البوت',
};

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const pageTitle = pageTitles[location] ?? 'مركز القيادة';

  return (
    <div dir="rtl" className="min-h-[100dvh] bg-background text-foreground">
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-[254px] flex-col border-l border-sidebar-border bg-sidebar text-sidebar-foreground md:flex">
        <div className="flex h-[86px] items-center gap-3 border-b border-sidebar-border px-6">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-[13px] bg-primary text-primary-foreground shadow-lg shadow-primary/20">
            <Activity className="h-5 w-5" strokeWidth={2.4} />
            <span className="absolute -bottom-1 -left-1 h-2.5 w-2.5 rounded-full border-2 border-sidebar bg-accent" />
          </div>
          <div>
            <div className="text-[15px] font-bold tracking-tight">مِسبار</div>
            <div className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-sidebar-foreground/50">FUTURES VIP</div>
          </div>
        </div>

        <div className="px-4 pt-7">
          <div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[0.16em] text-sidebar-foreground/40">التنقّل</div>
          <nav className="space-y-1.5">
            {navItems.map(({ href, label, icon: Icon }) => {
              const active = location === href;
              return (
                <Link
                  key={href}
                  href={href}
                  data-testid={`link-nav-${href === '/' ? 'overview' : href.slice(1)}`}
                  className={`nav-item group flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold no-underline ${
                    active
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground shadow-sm'
                      : 'text-sidebar-foreground/62 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'
                  }`}
                >
                  <Icon className={`h-[17px] w-[17px] ${active ? 'text-primary' : 'text-sidebar-foreground/50 group-hover:text-primary'}`} strokeWidth={2} />
                  <span>{label}</span>
                  {active && <ChevronLeft className="mr-auto h-4 w-4 text-sidebar-foreground/40" />}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="mt-auto p-4">
          <div className="rounded-2xl border border-sidebar-border bg-sidebar-accent/45 p-4">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-sidebar-foreground/60">حالة السوق</span>
              <span className="relative flex h-2 w-2">
                <span className="live-pulse absolute inline-flex h-full w-full rounded-full bg-accent" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
              </span>
            </div>
            <div className="font-mono-value text-[12px] text-sidebar-foreground/80">BINANCE / USDT-M</div>
            <div className="mt-2 text-[11px] text-accent">مراقبة نشطة · 24/7</div>
          </div>
          <div className="mt-4 flex items-center gap-3 px-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary">م</div>
            <div className="min-w-0">
              <div className="truncate text-xs font-semibold">حساب VIP</div>
              <div className="truncate text-[10px] text-sidebar-foreground/45">اتصال آمن</div>
            </div>
            <ShieldCheck className="mr-auto h-4 w-4 text-secondary" />
          </div>
        </div>
      </aside>

      <div className="md:pr-[254px]">
        <header className="sticky top-0 z-20 flex h-[70px] items-center justify-between border-b border-border/80 bg-background/90 px-5 backdrop-blur-xl md:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary md:hidden">
              <Bot className="h-4 w-4" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">FUTURES / CONTROL</div>
              <h1 className="mt-0.5 text-lg font-bold tracking-tight">{pageTitle}</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-[11px] font-semibold text-muted-foreground sm:flex">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              تنبيهات تيليجرام
            </div>
            <Link
              href="/signals"
              data-testid="link-header-generate"
              className="flex items-center gap-2 rounded-xl bg-primary px-3.5 py-2.5 text-xs font-bold text-primary-foreground no-underline shadow-sm shadow-primary/20 transition-transform hover:-translate-y-0.5"
            >
              <Activity className="h-3.5 w-3.5" />
              إشارة جديدة
            </Link>
          </div>
        </header>

        <main className="cockpit-grid min-h-[calc(100dvh-70px)] px-4 pb-24 pt-6 md:px-8 md:py-8">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 flex h-16 items-center justify-around border-t border-border bg-card/95 px-2 backdrop-blur-xl md:hidden">
        {navItems.map(({ href, label, icon: Icon }) => {
          const active = location === href;
          return (
            <Link
              key={href}
              href={href}
              data-testid={`link-mobile-nav-${href === '/' ? 'overview' : href.slice(1)}`}
              className={`flex min-w-[62px] flex-col items-center gap-1 rounded-xl px-2 py-1.5 text-[10px] font-semibold no-underline ${active ? 'text-primary' : 'text-muted-foreground'}`}
            >
              <Icon className="h-4 w-4" strokeWidth={active ? 2.5 : 1.9} />
              {label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}