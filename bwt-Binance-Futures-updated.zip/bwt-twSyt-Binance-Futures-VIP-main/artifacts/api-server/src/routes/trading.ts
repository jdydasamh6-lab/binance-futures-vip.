import { Router, type IRouter } from "express";
import {
  GenerateSignalBody,
  GenerateSignalResponse,
  GetBotSettingsResponse,
  GetDashboardOverviewResponse,
  GetMarketWatchlistResponse,
  GetPositionsResponse,
  GetRecentAlertsResponse,
  GetSignalsResponse,
  UpdateBotSettingsBody,
  UpdateBotSettingsResponse,
} from "@workspace/api-zod";
import {
  DEFAULT_SYMBOLS,
  analyzeFuturesSymbol,
  fetchClosedKlines,
  safeFetchFuturesMarket,
  type FuturesMarketPair,
} from "../lib/binance";
import { DEFAULT_CONFIG, netR, newTrade, stepTrade, type TradeState } from "../lib/strategy";
import { computeStats } from "../lib/stats";
import {
  formatSignalMessage,
  getTelegramStatus,
  sendTelegramMessage,
} from "../lib/telegram";
import {
  countActiveSignals,
  countSignalsSince,
  createAlert,
  createSignal,
  getSettings,
  hasActiveOrRecentSignal,
  initializeTradingStore,
  lastAlertOfType,
  listActiveSignals,
  listAlerts,
  listClosedResults,
  listSignals,
  toApiAlert,
  toApiPosition,
  toApiSignal,
  updateSettings,
  updateSignal,
} from "../lib/trading-store";

const router: IRouter = Router();

let market: FuturesMarketPair[] = [
  ...DEFAULT_SYMBOLS.map((symbol) => ({
    symbol,
    price: 0,
    change24h: 0,
    volume24h: 0,
    trend: "جارٍ التحميل",
    score: 0,
    timeframe: "15m",
  })),
];

let storeReady: Promise<void> | undefined;

function ensureStoreReady() {
  storeReady ??= initializeTradingStore();
  return storeReady;
}

async function refreshMarket() {
  const liveMarket = await safeFetchFuturesMarket();
  if (liveMarket && liveMarket.length > 0) market = liveMarket;
  return market;
}

function intervalLabel(intervalMs: number) {
  if (intervalMs >= 3_600_000) return `كل ${Math.round(intervalMs / 3_600_000)} ساعة`;
  return `كل ${Math.max(1, Math.round(intervalMs / 60_000))} دقائق`;
}

function intervalMsFromLabel(label: string) {
  if (label.includes("ساعة")) return 3_600_000;
  const number = Number(label.match(/\d+/)?.[0] ?? 5);
  return Math.min(Math.max(number, 1), 60) * 60_000;
}

async function getPublicSettings() {
  const settings = await getSettings();
  const telegramStatus = await getTelegramStatus();
  if (settings.telegramStatus !== telegramStatus) {
    return updateSettings({ telegramStatus });
  }
  return settings;
}

async function sendEvent(input: {
  signalId?: string;
  type: string;
  title: string;
  detail: string;
}) {
  const delivered = await sendTelegramMessage(
    `<b>${input.title}</b>\n\n${input.detail}`,
  );
  await createAlert({
    id: `alert-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    signalId: input.signalId,
    type: input.type,
    title: input.title,
    detail: input.detail,
    status: delivered ? "تم الإرسال" : "فشل الإرسال",
    sentAt: delivered ? new Date() : undefined,
  });
  await updateSettings({ telegramStatus: delivered ? "متصل" : "غير متصل" });
  return delivered;
}

const MAX_DAILY_SIGNALS = Number(process.env["MAX_DAILY_SIGNALS"] ?? 6);
const MAX_ACTIVE_SIGNALS = Number(process.env["MAX_ACTIVE_SIGNALS"] ?? 5);
const SYMBOL_COOLDOWN_MS = Number(process.env["SYMBOL_COOLDOWN_HOURS"] ?? 4) * 3_600_000;
const CANDLE_MS = 15 * 60_000;

const REJECT_LABELS: Record<string, string> = {
  "low-liquidity": "السيولة ضعيفة",
  "htf-no-agreement": "فريمي 4h و1h غير متفقين على اتجاه",
  "btc-disagrees": "اتجاه BTC يخالف الصفقة",
  "btc-volatility-shock": "تذبذب BTC حاد حالياً",
  "funding-crowded-long": "الـ funding مزدحم للشراء",
  "funding-crowded-short": "الـ funding مزدحم للبيع",
  "no-pullback": "لا يوجد ارتداد على EMA20",
  "no-resumption": "لا توجد شمعة تأكيد",
  overextended: "السعر بعيد عن نقطة الدخول المثالية",
  "rsi-out-of-range": "RSI خارج النطاق المناسب",
  "low-volume": "الحجم ضعيف",
  "stop-too-tight": "وقف الخسارة ضيق جداً",
  "stop-too-wide": "وقف الخسارة واسع جداً",
  "score-below-min": "جودة الإشارة أقل من الحد الأدنى",
};
const rejectLabel = (reason: string) => REJECT_LABELS[reason] ?? reason;

const newId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

async function createLiveSignal(analysis: NonNullable<Awaited<ReturnType<typeof analyzeFuturesSymbol>>["analysis"]>) {
  const createdAt = new Date();
  const signal = await createSignal({
    id: newId("sig"),
    ...analysis,
    createdAt,
    status: "نشطة",
  });
  const apiSignal = toApiSignal(signal);
  const delivered = await sendTelegramMessage(formatSignalMessage(apiSignal));
  await createAlert({
    id: newId("alert"),
    signalId: signal.id,
    type: "signal",
    title: delivered ? "إشارة جديدة أُرسلت" : "فشل إرسال الإشارة",
    detail: `${signal.symbol} ${signal.direction} · جودة ${signal.confidence}`,
    status: delivered ? "تم الإرسال" : "فشل الإرسال",
    sentAt: delivered ? new Date() : undefined,
  });
  await updateSettings({ telegramStatus: delivered ? "متصل" : "غير متصل" });
  return apiSignal;
}

const fmtR = (r: number) => `${r >= 0 ? "+" : ""}${r.toFixed(2)}R`;

let monitorRunning = false;

/** Tracks every active signal using CLOSED 15m candles (catches wicks; stop wins ties). */
export async function refreshActiveSignals() {
  if (monitorRunning) return;
  monitorRunning = true;
  try {
    await ensureStoreReady();
    const currentMarket = await refreshMarket();
    const prices = new Map(currentMarket.map((pair) => [pair.symbol, pair.price]));
    const settings = await getSettings();
    const cfg = { ...DEFAULT_CONFIG, breakEvenAfterTp1: settings.autoBreakEven };

    for (const signal of await listActiveSignals()) {
      if (signal.riskDistance == null || signal.signalCandleTime == null) {
        // legacy row without R data: cannot be tracked honestly, keep it out of the stats
        await updateSignal(signal.id, { status: "مؤرشفة", closedAt: new Date() });
        continue;
      }
      try {
        const from = (signal.lastCandleTime ?? signal.signalCandleTime) + 1;
        const candles = (await fetchClosedKlines(signal.symbol, "15m", 500, from)).filter(
          (candle) => candle.openTime > (signal.lastCandleTime ?? signal.signalCandleTime ?? 0),
        );

        let state: TradeState = {
          ...newTrade({
            direction: signal.direction as "LONG" | "SHORT",
            entry: signal.entryPrice,
            stop: signal.stopLoss,
            risk: signal.riskDistance,
            targets: [signal.tp1Price, signal.tp2Price, signal.tp3Price],
          }),
          hit: [signal.tp1Status === "متحقق", signal.tp2Status === "متحقق", signal.tp3Status === "متحقق"],
          remaining: signal.remaining,
          realizedR: signal.realizedR,
          breakEven: signal.breakEvenMoved,
          candlesHeld: Math.max(0, Math.round(((signal.lastCandleTime ?? signal.signalCandleTime) - signal.signalCandleTime) / CANDLE_MS)),
        };

        const messages: Array<{ type: string; title: string; detail: string }> = [];
        let lastCandleTime = signal.lastCandleTime ?? signal.signalCandleTime;
        for (const candle of candles) {
          const step = stepTrade(state, candle, cfg);
          state = step.state;
          lastCandleTime = candle.closeTime;
          for (const event of step.events) {
            const base = `${signal.symbol} ${signal.direction}`;
            if (event.type === "SL") messages.push({ type: "stop-loss", title: "ضرب وقف الخسارة", detail: `${base} · الخروج ${event.price}` });
            else if (event.type === "BE") messages.push({ type: "break-even", title: "خروج عند التعادل", detail: `${base} · الخروج ${event.price}` });
            else if (event.type === "TIMEOUT") messages.push({ type: "timeout", title: "إغلاق بانتهاء المدة", detail: `${base} · السعر ${event.price}` });
            else {
              messages.push({ type: "target", title: `تحقق ${event.type}`, detail: `${base} · السعر ${event.price}` });
              if (event.type === "TP1" && state.breakEven)
                messages.push({ type: "break-even", title: "نقل الوقف إلى الدخول", detail: `${signal.symbol} · الوقف الجديد ${signal.entryPrice}` });
            }
          }
          if (state.closed) break;
        }

        const result = state.closed ? netR(state, signal.costR) : null;
        await updateSignal(signal.id, {
          tp1Status: state.hit[0] ? "متحقق" : signal.tp1Status,
          tp2Status: state.hit[1] ? "متحقق" : signal.tp2Status,
          tp3Status: state.hit[2] ? "متحقق" : signal.tp3Status,
          stopLoss: state.stop,
          breakEvenMoved: state.breakEven,
          remaining: state.remaining,
          realizedR: state.realizedR,
          lastCandleTime,
          currentPrice: prices.get(signal.symbol) ?? candles.at(-1)?.close ?? signal.currentPrice,
          ...(state.closed
            ? {
                status: `مغلقة · ${state.exitReason}`,
                exitReason: state.exitReason,
                resultR: result,
                closedAt: new Date(),
              }
            : {}),
        });
        for (const message of messages) {
          const isFinal = state.closed && message === messages[messages.length - 1];
          await sendEvent({
            signalId: signal.id,
            type: message.type,
            title: message.title,
            detail: isFinal && result !== null ? `${message.detail}\nالنتيجة النهائية بعد الرسوم: ${fmtR(result)}` : message.detail,
          });
        }
      } catch (error) {
        logger.warn({ err: error, symbol: signal.symbol }, "Signal tracking failed");
      }
    }
  } finally {
    monitorRunning = false;
  }
}

let scanRunning = false;

export async function runAutomaticMarketScan() {
  if (scanRunning) return;
  scanRunning = true;
  try {
    await ensureStoreReady();
    await refreshMarket();
    const settings = await getSettings();

    const dayStart = new Date();
    dayStart.setUTCHours(0, 0, 0, 0);
    const slotsToday = MAX_DAILY_SIGNALS - (await countSignalsSince(dayStart));
    const slotsOpen = MAX_ACTIVE_SIGNALS - (await countActiveSignals());
    const slots = Math.min(slotsToday, slotsOpen);

    if (slots > 0) {
      type Found = NonNullable<Awaited<ReturnType<typeof analyzeFuturesSymbol>>["analysis"]>;
      const found: Found[] = [];
      const rejects: Record<string, number> = {};
      const symbols = market.map((pair) => pair.symbol);
      for (let i = 0; i < symbols.length; i += 5) {
        await Promise.all(
          symbols.slice(i, i + 5).map(async (symbol) => {
            try {
              if (await hasActiveOrRecentSignal(symbol, SYMBOL_COOLDOWN_MS)) return;
              const { analysis, reject } = await analyzeFuturesSymbol(symbol, settings.minConfidence);
              if (analysis) found.push(analysis);
              else if (reject) rejects[reject] = (rejects[reject] ?? 0) + 1;
            } catch (error) {
              logger.warn({ err: error, symbol }, "Symbol analysis failed");
            }
          }),
        );
      }
      logger.info({ found: found.length, rejects }, "Scan finished");
      // quality over quantity: best scores first, limited by remaining slots
      found.sort((a, b) => b.confidence - a.confidence);
      for (const analysis of found.slice(0, slots)) {
        await createLiveSignal(analysis);
      }
    } else {
      logger.info({ slotsToday, slotsOpen }, "Signal limit reached, scan skipped");
    }
    await refreshActiveSignals();
    await maybeSendReports();
  } finally {
    scanRunning = false;
  }
}

function reportText(label: string, stats: ReturnType<typeof computeStats>) {
  if (stats.trades === 0) return `${label}: لا توجد صفقات مغلقة.`;
  return [
    `${label}`,
    `الصفقات: ${stats.trades} (رابحة ${stats.wins} · خاسرة ${stats.losses} · تعادل ${stats.breakeven})`,
    `نسبة الربح: ${stats.winRate}%`,
    `صافي R بعد الرسوم: ${fmtR(stats.totalR)} · متوسط ${fmtR(stats.avgR)}`,
    `Profit Factor: ${stats.profitFactor ?? "—"}`,
    `أقصى تراجع: ${stats.maxDrawdownR}R`,
    "",
    "النتائج السابقة لا تضمن المستقبل. هذه ليست نصيحة مالية.",
  ].join("\n");
}

async function maybeSendReports() {
  const now = Date.now();
  const plans = [
    { type: "report-weekly", label: "التقرير الأسبوعي", ms: 7 * 86_400_000 },
    { type: "report-monthly", label: "التقرير الشهري", ms: 30 * 86_400_000 },
  ];
  for (const plan of plans) {
    const last = await lastAlertOfType(plan.type);
    if (last && now - last.timestamp.getTime() < plan.ms) continue;
    const results = await listClosedResults(new Date(now - plan.ms));
    if (results.length === 0) continue;
    await sendEvent({
      type: plan.type,
      title: plan.label,
      detail: reportText(plan.label, computeStats(results)),
    });
  }
}

router.get("/dashboard/overview", async (_req, res) => {
  await ensureStoreReady();
  const [settings, signals, results] = await Promise.all([getPublicSettings(), listSignals(), listClosedResults()]);
  await refreshMarket();
  const stats = computeStats(results);
  res.json(GetDashboardOverviewResponse.parse({
    marketStatus: market.some((pair) => pair.price > 0) ? "نشط" : "غير متصل",
    activeSignals: signals.filter((signal) => signal.status === "نشطة").length,
    winRate: stats.winRate, // real closed trades only, net of fees
    totalPnl: stats.totalR, // cumulative R after fees (not %)
    telegramStatus: settings.telegramStatus,
    lastScanAt: new Date().toISOString(),
  }));
});

router.get("/stats", async (_req, res) => {
  await ensureStoreReady();
  const day = 86_400_000;
  const since = (days: number) => new Date(Date.now() - days * day);
  const [all, d30, d7] = await Promise.all([
    listClosedResults(),
    listClosedResults(since(30)),
    listClosedResults(since(7)),
  ]);
  res.json({
    unit: "R (net of fees and slippage)",
    allTime: computeStats(all),
    last30d: computeStats(d30),
    last7d: computeStats(d7),
    disclaimer: "Past results do not guarantee future performance. Not financial advice.",
  });
});

router.get("/market/watchlist", async (_req, res) => {
  await ensureStoreReady();
  res.json(GetMarketWatchlistResponse.parse(await refreshMarket()));
});

router.get("/signals", async (_req, res) => {
  await ensureStoreReady();
  res.json(GetSignalsResponse.parse((await listSignals()).map(toApiSignal)));
});

router.post("/signals", async (req, res) => {
  await ensureStoreReady();
  const input = GenerateSignalBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "العملة والفريم مطلوبان بصيغة صحيحة." });
    return;
  }
  await refreshMarket();
  const symbol = input.data.symbol.toUpperCase();
  const pair = market.find((item) => item.symbol === symbol);
  if (!pair) {
    res.status(400).json({ error: "العملة غير موجودة في قائمة المتابعة." });
    return;
  }
  if (await hasActiveOrRecentSignal(pair.symbol, SYMBOL_COOLDOWN_MS)) {
    res.status(409).json({ error: "يوجد إشارة نشطة أو حديثة لهذه العملة." });
    return;
  }
  const settings = await getSettings();
  const { analysis, reject } = await analyzeFuturesSymbol(pair.symbol, settings.minConfidence);
  if (!analysis) {
    res.status(422).json({ error: `لا توجد صفقة مناسبة الآن: ${rejectLabel(reject ?? "unknown")}` });
    return;
  }
  res.status(201).json(GenerateSignalResponse.parse(await createLiveSignal(analysis)));
});

router.get("/positions", async (_req, res) => {
  await ensureStoreReady();
  await refreshActiveSignals();
  res.json(GetPositionsResponse.parse((await listActiveSignals()).map(toApiPosition)));
});

router.get("/alerts/recent", async (_req, res) => {
  await ensureStoreReady();
  res.json(GetRecentAlertsResponse.parse((await listAlerts()).map(toApiAlert)));
});

router.get("/settings", async (_req, res) => {
  await ensureStoreReady();
  const settings = await getPublicSettings();
  res.json(GetBotSettingsResponse.parse({
    scanInterval: intervalLabel(settings.scanIntervalMs),
    minConfidence: settings.minConfidence,
    defaultLeverage: settings.defaultLeverage,
    autoBreakEven: settings.autoBreakEven,
    telegramStatus: settings.telegramStatus,
  }));
});

router.patch("/settings", async (req, res) => {
  await ensureStoreReady();
  const input = UpdateBotSettingsBody.safeParse(req.body);
  if (!input.success) {
    res.status(400).json({ error: "إعدادات غير صالحة." });
    return;
  }
  const updated = await updateSettings({
    scanIntervalMs: input.data.scanInterval ? intervalMsFromLabel(input.data.scanInterval) : undefined,
    minConfidence: input.data.minConfidence,
    defaultLeverage: input.data.defaultLeverage,
    autoBreakEven: input.data.autoBreakEven,
  });
  res.json(UpdateBotSettingsResponse.parse({
    scanInterval: intervalLabel(updated.scanIntervalMs),
    minConfidence: updated.minConfidence,
    defaultLeverage: updated.defaultLeverage,
    autoBreakEven: updated.autoBreakEven,
    telegramStatus: updated.telegramStatus,
  }));
});

export default router;