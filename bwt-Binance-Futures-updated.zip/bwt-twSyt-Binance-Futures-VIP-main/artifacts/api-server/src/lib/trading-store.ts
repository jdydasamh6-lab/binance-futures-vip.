import { and, desc, eq, gte, inArray, isNotNull, isNull, sql } from "drizzle-orm";
import {
  alertEventsTable,
  botSettingsTable,
  db,
  signalTargetsTable,
  tradingSignalsTable,
  type BotSettings,
  type TradingSignal,
} from "@workspace/db";

export type ApiTarget = {
  label: string;
  price: number;
  percent: number;
  status: string;
};

export type ApiSignal = {
  id: string;
  symbol: string;
  direction: string;
  entryPrice: number;
  stopLoss: number;
  leverage: string;
  confidence: number;
  reason: string;
  timeframe: string;
  createdAt: string;
  targets: ApiTarget[];
  status: string;
};

export type ApiAlert = {
  id: string;
  type: string;
  title: string;
  detail: string;
  timestamp: string;
  status: string;
};

export async function initializeTradingStore() {
  const existingSettings = await db
    .select()
    .from(botSettingsTable)
    .where(eq(botSettingsTable.id, 1))
    .limit(1);
  if (existingSettings.length === 0) {
    await db.insert(botSettingsTable).values({ id: 1 });
  }

  // Remove demo rows from older versions so they never pollute the track record.
  const seedIds = ["sig-btc-seed", "sig-xrp-seed", "alert-seed-1", "alert-seed-2"];
  await db.delete(alertEventsTable).where(inArray(alertEventsTable.id, seedIds));
  await db.delete(signalTargetsTable).where(inArray(signalTargetsTable.signalId, seedIds));
  await db.delete(tradingSignalsTable).where(inArray(tradingSignalsTable.id, seedIds));
  // Legacy live signals have no risk data and cannot be tracked in R: archive them.
  await db
    .update(tradingSignalsTable)
    .set({ status: "مغلقة · أرشيف", closedAt: new Date() })
    .where(and(eq(tradingSignalsTable.status, "نشطة"), isNull(tradingSignalsTable.riskDistance)));

  const signals = await db.select().from(tradingSignalsTable);
  const existingTargets = await db
    .select({ signalId: signalTargetsTable.signalId })
    .from(signalTargetsTable);
  const targetSignalIds = new Set(existingTargets.map((target) => target.signalId));
  const missingTargets = signals
    .filter((signal) => !targetSignalIds.has(signal.id))
    .flatMap((signal) => [
      {
        signalId: signal.id,
        label: "TP1",
        price: signal.tp1Price,
        percent: signal.tp1Percent,
        status: signal.tp1Status,
        sortOrder: 1,
      },
      {
        signalId: signal.id,
        label: "TP2",
        price: signal.tp2Price,
        percent: signal.tp2Percent,
        status: signal.tp2Status,
        sortOrder: 2,
      },
      {
        signalId: signal.id,
        label: "TP3",
        price: signal.tp3Price,
        percent: signal.tp3Percent,
        status: signal.tp3Status,
        sortOrder: 3,
      },
    ]);
  if (missingTargets.length > 0) {
    await db.insert(signalTargetsTable).values(missingTargets);
  }
}

export async function getSettings(): Promise<BotSettings> {
  const rows = await db.select().from(botSettingsTable).where(eq(botSettingsTable.id, 1)).limit(1);
  if (!rows[0]) throw new Error("Bot settings have not been initialized");
  return rows[0];
}

export async function updateSettings(input: Partial<Pick<BotSettings, "scanIntervalMs" | "minConfidence" | "defaultLeverage" | "autoBreakEven" | "telegramStatus">>) {
  const [updated] = await db
    .update(botSettingsTable)
    .set({ ...input, updatedAt: new Date() })
    .where(eq(botSettingsTable.id, 1))
    .returning();
  if (!updated) throw new Error("Bot settings could not be updated");
  return updated;
}

export async function listSignals() {
  return db.select().from(tradingSignalsTable).orderBy(desc(tradingSignalsTable.createdAt)).limit(50);
}

export async function listActiveSignals() {
  return db
    .select()
    .from(tradingSignalsTable)
    .where(eq(tradingSignalsTable.status, "نشطة"))
    .orderBy(desc(tradingSignalsTable.createdAt));
}

export async function createSignal(input: {
  id: string;
  symbol: string;
  direction: string;
  entryPrice: number;
  stopLoss: number;
  leverage: string;
  confidence: number;
  reason: string;
  timeframe: string;
  createdAt: Date;
  status: string;
  targets: ApiTarget[];
  riskDistance: number;
  costR: number;
  signalCandleTime: number;
}) {
  const [created] = await db
    .insert(tradingSignalsTable)
    .values({
      id: input.id,
      symbol: input.symbol,
      direction: input.direction,
      entryPrice: input.entryPrice,
      stopLoss: input.stopLoss,
      leverage: input.leverage,
      confidence: input.confidence,
      reason: input.reason,
      timeframe: input.timeframe,
      createdAt: input.createdAt,
      status: input.status,
      tp1Price: input.targets[0]?.price ?? input.entryPrice,
      tp1Percent: input.targets[0]?.percent ?? 35,
      tp1Status: input.targets[0]?.status ?? "قيد المراقبة",
      tp2Price: input.targets[1]?.price ?? input.entryPrice,
      tp2Percent: input.targets[1]?.percent ?? 35,
      tp2Status: input.targets[1]?.status ?? "قيد المراقبة",
      tp3Price: input.targets[2]?.price ?? input.entryPrice,
      tp3Percent: input.targets[2]?.percent ?? 30,
      tp3Status: input.targets[2]?.status ?? "قيد المراقبة",
      currentPrice: input.entryPrice,
      riskDistance: input.riskDistance,
      initialStop: input.stopLoss,
      costR: input.costR,
      signalCandleTime: input.signalCandleTime,
      lastCandleTime: input.signalCandleTime,
    })
    .returning();
  if (!created) throw new Error("Signal could not be created");
  await db.insert(signalTargetsTable).values(
    input.targets.map((target, index) => ({
      signalId: created.id,
      label: target.label,
      price: target.price,
      percent: target.percent,
      status: target.status,
      sortOrder: index + 1,
    })),
  );
  return created;
}

export async function updateSignal(
  id: string,
  input: Partial<Omit<TradingSignal, "id" | "createdAt">>,
) {
  const [updated] = await db
    .update(tradingSignalsTable)
    .set(input)
    .where(eq(tradingSignalsTable.id, id))
    .returning();
  const targetStatusUpdates = [
    ["TP1", input.tp1Status],
    ["TP2", input.tp2Status],
    ["TP3", input.tp3Status],
  ] as const;
  for (const [label, status] of targetStatusUpdates) {
    if (status) {
      await db
        .update(signalTargetsTable)
        .set({ status })
        .where(and(eq(signalTargetsTable.signalId, id), eq(signalTargetsTable.label, label)));
    }
  }
  return updated;
}

export async function createAlert(input: {
  id: string;
  signalId?: string;
  type: string;
  title: string;
  detail: string;
  status: string;
  sentAt?: Date;
}) {
  const [created] = await db
    .insert(alertEventsTable)
    .values({
      id: input.id,
      signalId: input.signalId,
      type: input.type,
      title: input.title,
      detail: input.detail,
      status: input.status,
      sentAt: input.sentAt,
      timestamp: new Date(),
    })
    .returning();
  return created;
}

export async function listAlerts() {
  return db.select().from(alertEventsTable).orderBy(desc(alertEventsTable.timestamp)).limit(50);
}

export function toApiSignal(signal: TradingSignal): ApiSignal {
  return {
    id: signal.id,
    symbol: signal.symbol,
    direction: signal.direction,
    entryPrice: signal.entryPrice,
    stopLoss: signal.stopLoss,
    leverage: signal.leverage,
    confidence: signal.confidence,
    reason: signal.reason,
    timeframe: signal.timeframe,
    createdAt: signal.createdAt.toISOString(),
    targets: [
      { label: "TP1", price: signal.tp1Price, percent: signal.tp1Percent, status: signal.tp1Status },
      { label: "TP2", price: signal.tp2Price, percent: signal.tp2Percent, status: signal.tp2Status },
      { label: "TP3", price: signal.tp3Price, percent: signal.tp3Percent, status: signal.tp3Status },
    ],
    status: signal.status,
  };
}

export function toApiAlert(alert: Awaited<ReturnType<typeof listAlerts>>[number]): ApiAlert {
  return {
    id: alert.id,
    type: alert.type,
    title: alert.title,
    detail: alert.detail,
    timestamp: alert.timestamp.toISOString(),
    status: alert.status,
  };
}

export function toApiPosition(signal: TradingSignal) {
  const markPrice = signal.currentPrice ?? signal.entryPrice;
  const directionMultiplier = signal.direction === "LONG" ? 1 : -1;
  const pnlPercent = ((markPrice - signal.entryPrice) / signal.entryPrice) * directionMultiplier * 100;
  const progress =
    signal.tp3Status === "متحقق" ? 100 : signal.tp2Status === "متحقق" ? 66 : signal.tp1Status === "متحقق" ? 33 : 0;
  return {
    id: signal.id,
    symbol: signal.symbol,
    direction: signal.direction,
    entry: signal.entryPrice,
    markPrice,
    pnl: Number(pnlPercent.toFixed(2)),
    pnlPercent: Number(pnlPercent.toFixed(2)),
    leverage: signal.leverage,
    size: 1,
    progress,
    status: signal.breakEvenMoved ? `${signal.tp2Status} · SL إلى التعادل` : signal.tp1Status,
  };
}

export async function findRecentSignal(symbol: string, withinMs: number) {
  const rows = await db
    .select()
    .from(tradingSignalsTable)
    .where(and(eq(tradingSignalsTable.symbol, symbol), eq(tradingSignalsTable.status, "نشطة")))
    .orderBy(desc(tradingSignalsTable.createdAt))
    .limit(1);
  const signal = rows[0];
  if (!signal) return undefined;
  return Date.now() - signal.createdAt.getTime() < withinMs ? signal : undefined;
}

export async function countSignalsSince(since: Date) {
  const rows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tradingSignalsTable)
    .where(and(gte(tradingSignalsTable.createdAt, since), isNotNull(tradingSignalsTable.riskDistance)));
  return rows[0]?.count ?? 0;
}

export async function countActiveSignals() {
  const rows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(tradingSignalsTable)
    .where(eq(tradingSignalsTable.status, "نشطة"));
  return rows[0]?.count ?? 0;
}

/** True if the symbol has an active signal or any signal created within `withinMs`. */
export async function hasActiveOrRecentSignal(symbol: string, withinMs: number) {
  const rows = await db
    .select()
    .from(tradingSignalsTable)
    .where(eq(tradingSignalsTable.symbol, symbol))
    .orderBy(desc(tradingSignalsTable.createdAt))
    .limit(1);
  const last = rows[0];
  if (!last) return false;
  return last.status === "نشطة" || Date.now() - last.createdAt.getTime() < withinMs;
}

export async function listClosedResults(since?: Date) {
  const rows = await db
    .select({ r: tradingSignalsTable.resultR, closedAt: tradingSignalsTable.closedAt, exitReason: tradingSignalsTable.exitReason })
    .from(tradingSignalsTable)
    .where(
      since
        ? and(isNotNull(tradingSignalsTable.resultR), gte(tradingSignalsTable.closedAt, since))
        : isNotNull(tradingSignalsTable.resultR),
    );
  return rows
    .filter((row) => row.r !== null && row.closedAt !== null)
    .map((row) => ({ r: row.r as number, closedAt: (row.closedAt as Date).getTime(), exitReason: row.exitReason }));
}

export async function lastAlertOfType(type: string) {
  const rows = await db
    .select()
    .from(alertEventsTable)
    .where(eq(alertEventsTable.type, type))
    .orderBy(desc(alertEventsTable.timestamp))
    .limit(1);
  return rows[0];
}
