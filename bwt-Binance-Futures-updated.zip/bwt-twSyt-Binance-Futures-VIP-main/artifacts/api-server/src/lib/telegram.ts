import { logger } from "./logger";

type TelegramResponse<T> = {
  ok: boolean;
  result?: T;
  description?: string;
};

let verificationCache: { status: string; checkedAt: number } | undefined;

function getTelegramConfig() {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  const chatId = process.env["TELEGRAM_CHAT_ID"];
  return token && chatId ? { token, chatId } : undefined;
}

async function telegramRequest<T>(
  token: string,
  method: string,
  body?: Record<string, string>,
): Promise<TelegramResponse<T>> {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(8_000),
  });

  const payload = (await response.json()) as TelegramResponse<T>;
  if (!response.ok) {
    throw new Error(payload.description ?? `Telegram returned ${response.status}`);
  }
  return payload;
}

export async function getTelegramStatus(): Promise<string> {
  const config = getTelegramConfig();
  if (!config) return "غير متصل";

  const now = Date.now();
  if (verificationCache && now - verificationCache.checkedAt < 30_000) {
    return verificationCache.status;
  }

  try {
    const result = await telegramRequest<{ id: number }>(config.token, "getMe");
    const status = result.ok ? "متصل" : "غير متصل";
    verificationCache = { status, checkedAt: now };
    return status;
  } catch (error) {
    logger.warn({ err: error }, "Telegram connection check failed");
    verificationCache = { status: "غير متصل", checkedAt: now };
    return "غير متصل";
  }
}

export async function sendTelegramMessage(text: string): Promise<boolean> {
  const config = getTelegramConfig();
  if (!config) return false;

  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const result = await telegramRequest(config.token, "sendMessage", {
        chat_id: config.chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: "true",
      });
      verificationCache = { status: result.ok ? "متصل" : "غير متصل", checkedAt: Date.now() };
      return result.ok;
    } catch (error) {
      logger.warn({ err: error, attempt }, "Telegram delivery failed");
      if (attempt < 3) await new Promise((resolve) => setTimeout(resolve, attempt * 1500));
    }
  }
  verificationCache = { status: "غير متصل", checkedAt: Date.now() };
  return false;
}

export function formatSignalMessage(signal: {
  symbol: string;
  direction: string;
  entryPrice: number;
  stopLoss: number;
  leverage: string;
  confidence: number;
  reason: string;
  timeframe: string;
  targets: Array<{ label: string; price: number; percent: number }>;
}) {
  const directionLabel = signal.direction === "LONG" ? "شراء LONG" : "بيع SHORT";
  const riskDistance = Math.abs(signal.entryPrice - signal.stopLoss) || 1;
  const riskPct = (riskDistance / signal.entryPrice) * 100;
  const targets = signal.targets
    .map((target) => {
      const rr = Math.abs(target.price - signal.entryPrice) / riskDistance;
      return `<b>${target.label}</b>: ${target.price} · ${rr.toFixed(1)}R (إغلاق ${target.percent}%)`;
    })
    .join("\n");

  return [
    "<b>إشارة Futures VIP جديدة</b>",
    "",
    `<b>العملة:</b> ${signal.symbol}`,
    `<b>الاتجاه:</b> ${directionLabel}`,
    `<b>الفريم:</b> ${signal.timeframe}`,
    `<b>الدخول:</b> ${signal.entryPrice}`,
    `<b>وقف الخسارة:</b> ${signal.stopLoss} (${riskPct.toFixed(2)}%)`,
    `<b>المخاطرة المقترحة:</b> 1% من الرصيد (الرافعة ${signal.leverage})`,
    `<b>درجة الجودة:</b> ${signal.confidence}/100 (ترتيب فقط، ليست احتمال ربح)`,
    "",
    "<b>الأهداف:</b>",
    targets,
    "",
    `<b>سبب الدخول:</b> ${signal.reason}`,
    "",
    "<i>ليست نصيحة مالية. النتائج السابقة لا تضمن المستقبل. التزم بحجم المخاطرة.</i>",
  ].join("\n");
}