import { logger } from "./logger";
import { DEFAULT_CONFIG, evaluate, suggestedLeverage, type Candle } from "./strategy";

const BINANCE_FUTURES_BASE_URL = "https://fapi.binance.com";
export const DEFAULT_SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "BNBUSDT",
  "SOLUSDT",
  "XRPUSDT",
  "ADAUSDT",
  "DOGEUSDT",
  "AVAXUSDT",
  "LINKUSDT",
  "DOTUSDT",
  "TRXUSDT",
  "LTCUSDT",
  "BCHUSDT",
  "NEARUSDT",
  "UNIUSDT",
  "APTUSDT",
  "FILUSDT",
  "ATOMUSDT",
  "ARBUSDT",
  "OPUSDT",
  "SUIUSDT",
  "INJUSDT",
  "SEIUSDT",
  "TIAUSDT",
  "AAVEUSDT",
  "ETCUSDT",
  "XLMUSDT",
  "HBARUSDT",
  "RUNEUSDT",
  "WIFUSDT",
];

type BinanceTicker = {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  quoteVolume: string;
};

export type FuturesMarketPair = {
  symbol: string;
  price: number;
  change24h: number;
  volume24h: number;
  trend: string;
  score: number;
  timeframe: string;
};

async function binanceRequest<T>(path: string, params: Record<string, string>) {
  const query = new URLSearchParams(params).toString();
  const response = await fetch(`${BINANCE_FUTURES_BASE_URL}${path}?${query}`, {
    signal: AbortSignal.timeout(8_000),
  });

  if (!response.ok) {
    throw new Error(`Binance Futures returned ${response.status}`);
  }

  return (await response.json()) as T;
}

function scoreMarket(change24h: number, volume24h: number) {
  const changeScore = Math.min(Math.abs(change24h) * 5, 30);
  const volumeScore = Math.min(Math.log10(Math.max(volume24h, 1)) * 3, 30);
  return Math.round(Math.min(98, 48 + changeScore + volumeScore));
}

function decimalsForPrice(price: number) {
  if (price >= 1000) return 2;
  if (price >= 1) return 4;
  return 6;
}

export function roundPrice(price: number) {
  return Number(price.toFixed(decimalsForPrice(price)));
}

export function candlesFromRows(rawCandles: unknown[][]): Candle[] {
  return rawCandles.map((row) => ({
    openTime: Number(row[0]),
    open: Number(row[1]),
    high: Number(row[2]),
    low: Number(row[3]),
    close: Number(row[4]),
    volume: Number(row[5]),
    closeTime: Number(row[6]),
    quoteVolume: Number(row[7]),
  }));
}

/** Drop the still-forming candle: strategy and tracking only use CLOSED candles. */
export function onlyClosed(candles: Candle[]) {
  const now = Date.now();
  return candles.filter((candle) => candle.closeTime < now);
}

export async function fetchClosedKlines(symbol: string, interval: string, limit = 200, startTime?: number) {
  const params: Record<string, string> = { symbol, interval, limit: String(limit) };
  if (startTime !== undefined) params["startTime"] = String(startTime);
  const rows = await binanceRequest<unknown[][]>("/fapi/v1/klines", params);
  return onlyClosed(candlesFromRows(rows));
}

async function fetchFundingRate(symbol: string): Promise<number | undefined> {
  try {
    const data = await binanceRequest<{ lastFundingRate: string }>("/fapi/v1/premiumIndex", { symbol });
    const rate = Number(data.lastFundingRate);
    return Number.isFinite(rate) ? rate : undefined;
  } catch {
    return undefined; // unknown funding does not block a signal
  }
}

let btcCache: { at: number; candles: Candle[] } | undefined;
async function getBtc1h() {
  if (btcCache && Date.now() - btcCache.at < 60_000) return btcCache.candles;
  const candles = await fetchClosedKlines("BTCUSDT", "1h", 200);
  btcCache = { at: Date.now(), candles };
  return candles;
}

export async function fetchFuturesMarket(
  symbols = DEFAULT_SYMBOLS,
): Promise<FuturesMarketPair[]> {
  const tickers = await binanceRequest<BinanceTicker[]>("/fapi/v1/ticker/24hr", {});
  const selected = new Map(tickers.map((ticker) => [ticker.symbol, ticker]));

  return symbols
    .map((symbol) => selected.get(symbol))
    .filter((ticker): ticker is BinanceTicker => Boolean(ticker))
    .map((ticker) => {
      const change24h = Number(ticker.priceChangePercent);
      return {
        symbol: ticker.symbol,
        price: Number(ticker.lastPrice),
        change24h,
        volume24h: Number(ticker.quoteVolume),
        trend: change24h > 1.2 ? "صاعد" : change24h < -1.2 ? "هابط" : "متذبذب",
        score: scoreMarket(change24h, Number(ticker.quoteVolume)),
        timeframe: "15m",
      };
    });
}

export type FuturesAnalysis = {
  symbol: string;
  direction: "LONG" | "SHORT";
  entryPrice: number;
  stopLoss: number;
  leverage: string;
  confidence: number;
  reason: string;
  timeframe: string;
  targets: Array<{ label: string; price: number; percent: number; status: string }>;
  riskDistance: number;
  riskPct: number;
  costR: number;
  signalCandleTime: number;
};

/** Returns a signal, or null (with a reason) when the strategy says "no trade". */
export async function analyzeFuturesSymbol(
  symbol: string,
  minScore: number,
): Promise<{ analysis?: FuturesAnalysis; reject?: string }> {
  const cfg = { ...DEFAULT_CONFIG, minScore };
  const [c15, c1h, c4h, btc1h, funding] = await Promise.all([
    fetchClosedKlines(symbol, "15m", 200),
    fetchClosedKlines(symbol, "1h", 200),
    fetchClosedKlines(symbol, "4h", 200),
    symbol === "BTCUSDT" ? Promise.resolve(undefined) : getBtc1h(),
    fetchFundingRate(symbol),
  ]);
  const result = evaluate({ symbol, c15, c1h, c4h, btc1h, funding, cfg });
  if (!result.ok) return { reject: result.reason };
  const s = result.setup;
  const alloc = cfg.alloc;
  const labels = ["TP1", "TP2", "TP3"] as const;
  return {
    analysis: {
      symbol,
      direction: s.direction,
      entryPrice: roundPrice(s.entry),
      stopLoss: roundPrice(s.stop),
      leverage: `${suggestedLeverage(s.riskPct, cfg)}x`,
      confidence: s.score,
      reason: s.reasons.join("، ") + ".",
      timeframe: "15m",
      targets: s.targets.map((price, index) => ({
        label: labels[index],
        price: roundPrice(price),
        percent: Math.round(alloc[index] * 100),
        status: "قيد المراقبة",
      })),
      riskDistance: s.risk,
      riskPct: s.riskPct,
      costR: s.costR,
      signalCandleTime: s.signalCandleTime,
    },
  };
}

export async function safeFetchFuturesMarket() {
  try {
    return await fetchFuturesMarket();
  } catch (error) {
    logger.warn({ err: error }, "Binance Futures market refresh failed");
    return undefined;
  }
}