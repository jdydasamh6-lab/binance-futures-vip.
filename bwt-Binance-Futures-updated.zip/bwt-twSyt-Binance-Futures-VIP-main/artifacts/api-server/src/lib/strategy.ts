/**
 * Strategy engine — pure functions, no I/O, no dependencies.
 * The SAME code is used by the live bot and by scripts/backtest.ts,
 * so backtest numbers describe what the bot actually does.
 *
 * Rules (all candles passed in MUST be closed candles):
 *  - Direction comes from the 4h AND 1h trend agreeing (EMA20/EMA50 + price vs EMA50).
 *  - Entry is a pullback to the 15m EMA20 that resumes in the trend direction.
 *  - Gates: liquidity, BTC 1h trend (for alts), BTC volatility shock, funding crowding,
 *    sane stop distance. If any gate fails -> NO signal.
 *  - Stop = 1.5 ATR. Targets = 1R / 2R / 3R, split 50% / 30% / 20%.
 *  - After TP1 the stop moves to entry (optional).
 *  - Costs (fees + slippage) are charged in R on every trade.
 */

export type Candle = {
  openTime: number;
  closeTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
};

export type Direction = "LONG" | "SHORT";
export type Trend = "UP" | "DOWN" | "FLAT";

export type StrategyConfig = {
  minScore: number;
  minQuoteVolume24h: number; // USDT traded in the last 96x15m candles
  maxFundingAbs: number; // e.g. 0.0005 = 0.05% per 8h
  atrStopMult: number;
  tpR: [number, number, number];
  alloc: [number, number, number];
  breakEvenAfterTp1: boolean;
  maxHoldCandles: number; // 15m candles
  minRiskPct: number;
  maxRiskPct: number;
  feeRatePerSide: number;
  slippagePerSide: number;
  riskPerTradePct: number; // suggested % of balance risked per signal
};

export const DEFAULT_CONFIG: StrategyConfig = {
  minScore: 80,
  minQuoteVolume24h: 50_000_000,
  maxFundingAbs: 0.0005,
  atrStopMult: 1.5,
  tpR: [1, 2, 3],
  alloc: [0.5, 0.3, 0.2],
  breakEvenAfterTp1: true,
  maxHoldCandles: 96, // 24h
  minRiskPct: 0.004,
  maxRiskPct: 0.04,
  feeRatePerSide: 0.0005,
  slippagePerSide: 0.0002,
  riskPerTradePct: 1,
};

// ---------- indicators ----------
function average(values: number[]) {
  return values.length ? values.reduce((a, b) => a + b, 0) / values.length : 0;
}

export function ema(values: number[], period: number) {
  if (values.length < period) return NaN;
  const k = 2 / (period + 1);
  let current = average(values.slice(0, period));
  for (let i = period; i < values.length; i += 1) current = (values[i] - current) * k + current;
  return current;
}

export function rsi(values: number[], period = 14) {
  if (values.length <= period) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = 1; i <= period; i += 1) {
    const ch = values[i] - values[i - 1];
    if (ch >= 0) gains += ch;
    else losses -= ch;
  }
  let ag = gains / period;
  let al = losses / period;
  for (let i = period + 1; i < values.length; i += 1) {
    const ch = values[i] - values[i - 1];
    ag = (ag * (period - 1) + Math.max(ch, 0)) / period;
    al = (al * (period - 1) + Math.max(-ch, 0)) / period;
  }
  if (al === 0) return 100;
  return 100 - 100 / (1 + ag / al);
}

export function atr(candles: Candle[], period = 14) {
  if (candles.length < period + 1) return NaN;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i += 1) {
    const c = candles[i];
    const pc = candles[i - 1].close;
    trs.push(Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc)));
  }
  return average(trs.slice(-period));
}

export function trendOf(candles: Candle[]): Trend {
  const closes = candles.map((c) => c.close);
  const fast = ema(closes, 20);
  const slow = ema(closes, 50);
  const last = closes[closes.length - 1];
  if (!Number.isFinite(fast) || !Number.isFinite(slow)) return "FLAT";
  if (fast > slow && last > slow) return "UP";
  if (fast < slow && last < slow) return "DOWN";
  return "FLAT";
}

// ---------- signal evaluation ----------
export type EvaluateInput = {
  symbol: string;
  c15: Candle[]; // closed 15m candles, oldest -> newest, >= 100
  c1h: Candle[]; // closed 1h candles, >= 60
  c4h: Candle[]; // closed 4h candles, >= 60
  btc1h?: Candle[]; // closed BTC 1h candles (required unless symbol is BTCUSDT)
  funding?: number; // latest funding rate, undefined = unknown
  cfg?: StrategyConfig;
};

export type Setup = {
  symbol: string;
  direction: Direction;
  entry: number;
  stop: number;
  risk: number; // price distance entry -> stop
  riskPct: number;
  targets: [number, number, number];
  costR: number;
  score: number;
  signalCandleTime: number; // closeTime of the signal candle
  reasons: string[];
};

export type EvaluateResult = { ok: true; setup: Setup } | { ok: false; reason: string };

const reject = (reason: string): EvaluateResult => ({ ok: false, reason });

export function evaluate(input: EvaluateInput): EvaluateResult {
  const cfg = input.cfg ?? DEFAULT_CONFIG;
  const { symbol, c15, c1h, c4h } = input;
  if (c15.length < 100 || c1h.length < 60 || c4h.length < 60) return reject("not-enough-data");

  const last = c15[c15.length - 1];
  const prev = c15[c15.length - 2];

  // 1) liquidity
  const quoteVol = c15.slice(-96).reduce((s, c) => s + c.quoteVolume, 0);
  if (quoteVol < cfg.minQuoteVolume24h) return reject("low-liquidity");

  // 2) higher-timeframe direction (must agree)
  const t4 = trendOf(c4h);
  const t1 = trendOf(c1h);
  if (t4 === "FLAT" || t1 === "FLAT" || t4 !== t1) return reject("htf-no-agreement");
  const direction: Direction = t4 === "UP" ? "LONG" : "SHORT";
  const sign = direction === "LONG" ? 1 : -1;

  // 3) BTC filter for alts
  const reasons: string[] = [
    `الفريم 4h و1h متفقان على اتجاه ${direction === "LONG" ? "صاعد" : "هابط"}`,
  ];
  let btcAligned = true;
  if (symbol !== "BTCUSDT") {
    if (!input.btc1h || input.btc1h.length < 60) return reject("no-btc-data");
    const tb = trendOf(input.btc1h);
    if (tb !== t1) return reject("btc-disagrees");
    const btcAtr = atr(input.btc1h.slice(0, -1), 14);
    const lastBtc = input.btc1h[input.btc1h.length - 1];
    if (Number.isFinite(btcAtr) && lastBtc.high - lastBtc.low > btcAtr * 3) return reject("btc-volatility-shock");
    reasons.push("اتجاه BTC على 1h يدعم الصفقة");
  } else {
    btcAligned = true;
  }

  // 4) funding crowding
  if (input.funding !== undefined) {
    if (direction === "LONG" && input.funding > cfg.maxFundingAbs) return reject("funding-crowded-long");
    if (direction === "SHORT" && input.funding < -cfg.maxFundingAbs) return reject("funding-crowded-short");
  }

  // 5) 15m pullback + resumption
  const closes = c15.map((c) => c.close);
  const ema20 = ema(closes, 20);
  const ema50 = ema(closes, 50);
  const a = atr(c15, 14);
  if (!Number.isFinite(ema20) || !Number.isFinite(a) || a <= 0) return reject("indicator-nan");

  const recent = c15.slice(-4);
  const touched =
    direction === "LONG"
      ? Math.min(...recent.map((c) => c.low)) <= ema20 + 0.3 * a
      : Math.max(...recent.map((c) => c.high)) >= ema20 - 0.3 * a;
  if (!touched) return reject("no-pullback");

  const resumed =
    direction === "LONG"
      ? last.close > ema20 && last.close > last.open && last.close > prev.high * 0.999
      : last.close < ema20 && last.close < last.open && last.close < prev.low * 1.001;
  if (!resumed) return reject("no-resumption");

  if (Math.abs(last.close - ema20) > 1.5 * a) return reject("overextended");

  const r = rsi(closes, 14);
  if (direction === "LONG" && (r < 42 || r > 65)) return reject("rsi-out-of-range");
  if (direction === "SHORT" && (r > 58 || r < 35)) return reject("rsi-out-of-range");

  const avgVol = average(c15.slice(-21, -1).map((c) => c.volume));
  const volRatio = avgVol > 0 ? last.volume / avgVol : 0;
  if (volRatio < 1.0) return reject("low-volume");

  // 6) trade plan
  const entry = last.close;
  const risk = cfg.atrStopMult * a;
  const riskPct = risk / entry;
  if (riskPct < cfg.minRiskPct) return reject("stop-too-tight");
  if (riskPct > cfg.maxRiskPct) return reject("stop-too-wide");
  const stop = entry - sign * risk;
  const targets = cfg.tpR.map((m) => entry + sign * risk * m) as [number, number, number];
  const costR = (2 * (cfg.feeRatePerSide + cfg.slippagePerSide) * entry) / risk;

  // 7) quality score (ranking only — NOT a win probability)
  let score = 62;
  if (volRatio >= 1.5) score += 8;
  else if (volRatio >= 1.2) score += 5;
  if (direction === "LONG" ? r >= 50 && r <= 60 : r <= 50 && r >= 40) score += 7;
  if (btcAligned) score += 6;
  if (input.funding !== undefined && (direction === "LONG" ? input.funding <= 0.0001 : input.funding >= -0.0001)) {
    score += 5;
    reasons.push("الـ funding غير مزدحم في اتجاه الصفقة");
  }
  if (Number.isFinite(ema50) && (direction === "LONG" ? ema20 > ema50 : ema20 < ema50)) score += 5;
  if (Math.abs(last.close - ema20) <= 0.8 * a) score += 4;
  score = Math.min(score, 95);
  if (score < cfg.minScore) return reject("score-below-min");

  reasons.push(
    `ارتداد على EMA20 (15m) وإغلاق شمعة تأكيد، RSI ${r.toFixed(0)}، الحجم ${volRatio.toFixed(1)}× المتوسط`,
  );

  return {
    ok: true,
    setup: {
      symbol,
      direction,
      entry,
      stop,
      risk,
      riskPct,
      targets,
      costR,
      score,
      signalCandleTime: last.closeTime,
      reasons,
    },
  };
}

// ---------- trade management (shared by live tracking and backtest) ----------
export type TradeState = {
  direction: Direction;
  entry: number;
  stop: number;
  risk: number;
  targets: [number, number, number];
  hit: [boolean, boolean, boolean];
  remaining: number; // fraction of position still open (0..1)
  realizedR: number; // gross R banked so far (before costs)
  candlesHeld: number;
  closed: boolean;
  exitReason?: "SL" | "BE" | "TP3" | "TIMEOUT";
  breakEven: boolean; // stop already moved to entry
};

export type TradeEvent = {
  type: "TP1" | "TP2" | "TP3" | "SL" | "BE" | "TIMEOUT";
  price: number;
  /** R banked by this event (gross, weighted by position fraction closed) */
  r: number;
};

export function newTrade(setup: Pick<Setup, "direction" | "entry" | "stop" | "risk" | "targets">): TradeState {
  return {
    direction: setup.direction,
    entry: setup.entry,
    stop: setup.stop,
    risk: setup.risk,
    targets: setup.targets,
    hit: [false, false, false],
    remaining: 1,
    realizedR: 0,
    candlesHeld: 0,
    closed: false,
    breakEven: false,
  };
}

/**
 * Advance a trade by ONE closed candle. Conservative ordering:
 * if the stop and a target are both touched inside the same candle, the STOP wins.
 * A stop moved to break-even only becomes active from the NEXT candle.
 */
export function stepTrade(
  state: TradeState,
  candle: Candle,
  cfg: StrategyConfig = DEFAULT_CONFIG,
): { state: TradeState; events: TradeEvent[] } {
  if (state.closed) return { state, events: [] };
  const s: TradeState = { ...state, hit: [...state.hit] as [boolean, boolean, boolean] };
  const events: TradeEvent[] = [];
  const sign = s.direction === "LONG" ? 1 : -1;
  const rOf = (price: number) => ((price - s.entry) * sign) / s.risk;

  const stopHit = s.direction === "LONG" ? candle.low <= s.stop : candle.high >= s.stop;
  if (stopHit) {
    const r = s.remaining * rOf(s.stop);
    s.realizedR += r;
    events.push({ type: s.breakEven ? "BE" : "SL", price: s.stop, r });
    s.remaining = 0;
    s.closed = true;
    s.exitReason = s.breakEven ? "BE" : "SL";
    s.candlesHeld += 1;
    return { state: s, events };
  }

  let movedToBreakEven = false;
  for (let i = 0; i < 3; i += 1) {
    if (s.hit[i]) continue;
    const reached = s.direction === "LONG" ? candle.high >= s.targets[i] : candle.low <= s.targets[i];
    if (!reached) break; // targets are ordered; later ones cannot be hit first
    const frac = i === 2 ? s.remaining : Math.min(cfg.alloc[i], s.remaining);
    const r = frac * cfg.tpR[i];
    s.hit[i] = true;
    s.remaining -= frac;
    s.realizedR += r;
    events.push({ type: (["TP1", "TP2", "TP3"] as const)[i], price: s.targets[i], r });
    if (i === 0 && cfg.breakEvenAfterTp1) movedToBreakEven = true;
  }
  if (s.hit[2] || s.remaining <= 1e-9) {
    s.remaining = 0;
    s.closed = true;
    s.exitReason = "TP3";
  }
  if (movedToBreakEven && !s.closed) {
    s.stop = s.entry;
    s.breakEven = true;
  }

  s.candlesHeld += 1;
  if (!s.closed && s.candlesHeld >= cfg.maxHoldCandles) {
    const r = s.remaining * rOf(candle.close);
    s.realizedR += r;
    events.push({ type: "TIMEOUT", price: candle.close, r });
    s.remaining = 0;
    s.closed = true;
    s.exitReason = "TIMEOUT";
  }
  return { state: s, events };
}

/** Net R of a finished trade after fees + slippage. */
export const netR = (state: TradeState, costR: number) => state.realizedR - costR;

export function suggestedLeverage(riskPct: number, cfg: StrategyConfig = DEFAULT_CONFIG) {
  // position notional / balance = riskPerTrade% / stopDistance%
  const notionalFraction = cfg.riskPerTradePct / 100 / riskPct;
  return Math.max(1, Math.ceil(notionalFraction));
}
