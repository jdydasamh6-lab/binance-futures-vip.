export type ClosedResult = { r: number; closedAt: number };

export type Stats = {
  trades: number;
  wins: number;
  losses: number;
  breakeven: number;
  winRate: number; // %
  avgR: number;
  totalR: number;
  profitFactor: number | null; // null = no losing trades yet
  maxDrawdownR: number;
  bestR: number;
  worstR: number;
};

const BE_EPS = 0.05; // |R| below this counts as break-even, not win/loss

export function computeStats(results: ClosedResult[]): Stats {
  const sorted = [...results].sort((a, b) => a.closedAt - b.closedAt);
  let wins = 0;
  let losses = 0;
  let breakeven = 0;
  let grossWin = 0;
  let grossLoss = 0;
  let cum = 0;
  let peak = 0;
  let maxDd = 0;
  let best = 0;
  let worst = 0;
  for (const { r } of sorted) {
    if (r > BE_EPS) {
      wins += 1;
      grossWin += r;
    } else if (r < -BE_EPS) {
      losses += 1;
      grossLoss += -r;
    } else {
      breakeven += 1;
    }
    cum += r;
    peak = Math.max(peak, cum);
    maxDd = Math.max(maxDd, peak - cum);
    best = Math.max(best, r);
    worst = Math.min(worst, r);
  }
  const n = sorted.length;
  const round = (x: number, d = 2) => Number(x.toFixed(d));
  return {
    trades: n,
    wins,
    losses,
    breakeven,
    winRate: n ? round((wins / n) * 100, 1) : 0,
    avgR: n ? round(cum / n) : 0,
    totalR: round(cum),
    profitFactor: grossLoss > 0 ? round(grossWin / grossLoss) : null,
    maxDrawdownR: round(maxDd),
    bestR: round(best),
    worstR: round(worst),
  };
}
