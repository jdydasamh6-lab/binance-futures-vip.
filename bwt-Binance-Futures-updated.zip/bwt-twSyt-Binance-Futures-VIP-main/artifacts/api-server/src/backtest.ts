/**
 * Backtest — runs the EXACT live strategy (src/lib/strategy.ts) over Binance history.
 *
 *   pnpm --filter @workspace/api-server run backtest
 *   BT_MONTHS=12 BT_SYMBOLS=BTCUSDT,ETHUSDT,SOLUSDT pnpm --filter @workspace/api-server run backtest
 *
 * Honest-by-construction rules:
 *  - decisions use only candles that were closed at that moment (no look-ahead)
 *  - fees + slippage are charged on every trade (cfg.feeRatePerSide / slippagePerSide)
 *  - if SL and a target are touched in the same candle, the stop wins
 *  - one open trade per symbol, 4h cooldown after it closes
 *  - results are split in-sample (first 2/3) vs out-of-sample (last 1/3) so overfitting shows up
 * Caveat: entry is assumed at the signal candle's close; live entry may be slightly worse.
 */
import { writeFileSync } from "node:fs";
import { computeStats } from "./lib/stats";
import {
  DEFAULT_CONFIG,
  evaluate,
  netR,
  newTrade,
  stepTrade,
  type Candle,
  type TradeState,
} from "./lib/strategy";

const BASE = "https://fapi.binance.com";
const MONTHS = Number(process.env["BT_MONTHS"] ?? 12);
const SYMBOLS = (process.env["BT_SYMBOLS"] ??
  "BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT,XRPUSDT,ADAUSDT,DOGEUSDT,AVAXUSDT,LINKUSDT,LTCUSDT,NEARUSDT,SUIUSDT")
  .split(",")
  .map((s) => s.trim().toUpperCase());
const MIN_SCORE = Number(process.env["BT_MIN_SCORE"] ?? DEFAULT_CONFIG.minScore);
const COOLDOWN_CANDLES = 16; // 4h of 15m candles
const WARMUP = 100;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function getJson<T>(path: string, params: Record<string, string>): Promise<T> {
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    const res = await fetch(`${BASE}${path}?${new URLSearchParams(params)}`);
    if (res.ok) return (await res.json()) as T;
    if (attempt === 4) throw new Error(`${path} -> HTTP ${res.status}`);
    await sleep(attempt * 1500);
  }
  throw new Error("unreachable");
}

async function fetchHistory(symbol: string, interval: string, startTime: number): Promise<Candle[]> {
  const out: Candle[] = [];
  let from = startTime;
  const now = Date.now();
  while (from < now) {
    const rows = await getJson<unknown[][]>("/fapi/v1/klines", { symbol, interval, startTime: String(from), limit: "1500" });
    if (rows.length === 0) break;
    for (const r of rows) {
      out.push({
        openTime: Number(r[0]), open: Number(r[1]), high: Number(r[2]), low: Number(r[3]),
        close: Number(r[4]), volume: Number(r[5]), closeTime: Number(r[6]), quoteVolume: Number(r[7]),
      });
    }
    from = out[out.length - 1].closeTime + 1;
    await sleep(120);
  }
  return out.filter((c) => c.closeTime < now);
}

async function fetchFunding(symbol: string, startTime: number): Promise<Array<{ t: number; rate: number }>> {
  const out: Array<{ t: number; rate: number }> = [];
  let from = startTime;
  while (true) {
    const rows = await getJson<Array<{ fundingTime: number; fundingRate: string }>>("/fapi/v1/fundingRate", {
      symbol, startTime: String(from), limit: "1000",
    });
    if (rows.length === 0) break;
    for (const r of rows) out.push({ t: r.fundingTime, rate: Number(r.fundingRate) });
    if (rows.length < 1000) break;
    from = rows[rows.length - 1].fundingTime + 1;
    await sleep(120);
  }
  return out;
}

type Trade = {
  symbol: string; direction: string; openedAt: number; closedAt: number;
  entry: number; score: number; exit: string; r: number;
};

function lastIndexAtOrBefore(candles: Candle[], time: number, from: number) {
  let i = from;
  while (i + 1 < candles.length && candles[i + 1].closeTime <= time) i += 1;
  return i;
}

async function backtestSymbol(symbol: string, start: number, btc1h: Candle[]): Promise<Trade[]> {
  const warmupMs = 20 * 86_400_000; // history before `start` so indicators are warm
  const [c15, c1h, c4h, funding] = await Promise.all([
    fetchHistory(symbol, "15m", start - warmupMs),
    fetchHistory(symbol, "1h", start - warmupMs * 3),
    fetchHistory(symbol, "4h", start - warmupMs * 8),
    fetchFunding(symbol, start - warmupMs).catch(() => []),
  ]);
  const trades: Trade[] = [];
  let i1 = 0, i4 = 0, ib = 0, iF = -1;
  let cooldownUntil = -1;

  for (let i = WARMUP; i < c15.length - 1; i += 1) {
    const now = c15[i];
    if (now.closeTime < start || i < cooldownUntil) continue;
    i1 = lastIndexAtOrBefore(c1h, now.closeTime, i1);
    i4 = lastIndexAtOrBefore(c4h, now.closeTime, i4);
    ib = lastIndexAtOrBefore(btc1h, now.closeTime, ib);
    while (iF + 1 < funding.length && funding[iF + 1].t <= now.closeTime) iF += 1;

    const result = evaluate({
      symbol,
      c15: c15.slice(Math.max(0, i - 199), i + 1),
      c1h: c1h.slice(Math.max(0, i1 - 199), i1 + 1),
      c4h: c4h.slice(Math.max(0, i4 - 199), i4 + 1),
      btc1h: symbol === "BTCUSDT" ? undefined : btc1h.slice(Math.max(0, ib - 199), ib + 1),
      funding: iF >= 0 ? funding[iF].rate : undefined,
      cfg: { ...DEFAULT_CONFIG, minScore: MIN_SCORE },
    });
    if (!result.ok) continue;

    const setup = result.setup;
    let state: TradeState = newTrade(setup);
    let j = i + 1;
    for (; j < c15.length && !state.closed; j += 1) state = stepTrade(state, c15[j], DEFAULT_CONFIG).state;
    if (!state.closed) break; // trade still open at end of data: excluded
    trades.push({
      symbol, direction: setup.direction, openedAt: now.closeTime, closedAt: c15[j - 1].closeTime,
      entry: setup.entry, score: setup.score, exit: state.exitReason ?? "?", r: netR(state, setup.costR),
    });
    cooldownUntil = j + COOLDOWN_CANDLES;
    i = j - 1;
  }
  return trades;
}

function line(label: string, trades: Trade[]) {
  const s = computeStats(trades.map((t) => ({ r: t.r, closedAt: t.closedAt })));
  console.log(
    `${label.padEnd(14)} n=${String(s.trades).padStart(4)}  win=${String(s.winRate).padStart(5)}%  avgR=${String(s.avgR).padStart(5)}  totalR=${String(s.totalR).padStart(7)}  PF=${s.profitFactor ?? "-"}  maxDD=${s.maxDrawdownR}R`,
  );
}

async function main() {
  const start = Date.now() - MONTHS * 30 * 86_400_000;
  console.log(`Backtest ${MONTHS} months · ${SYMBOLS.length} symbols · minScore ${MIN_SCORE} · fees+slippage included\n`);
  const btc1h = await fetchHistory("BTCUSDT", "1h", start - 60 * 86_400_000);
  const all: Trade[] = [];
  for (const symbol of SYMBOLS) {
    process.stdout.write(`${symbol}… `);
    try {
      const t = await backtestSymbol(symbol, start, btc1h);
      all.push(...t);
      console.log(`${t.length} trades`);
    } catch (error) {
      console.log(`failed (${(error as Error).message})`);
    }
  }
  all.sort((a, b) => a.closedAt - b.closedAt);
  console.log("\n=== Results (R = multiples of the risked amount, net of costs) ===");
  line("ALL", all);
  const split = start + (Date.now() - start) * (2 / 3);
  line("In-sample 2/3", all.filter((t) => t.closedAt < split));
  line("Out-of-sample", all.filter((t) => t.closedAt >= split));
  console.log("\nBy symbol:");
  for (const s of SYMBOLS) line(s, all.filter((t) => t.symbol === s));
  console.log("\nBy direction:");
  for (const d of ["LONG", "SHORT"]) line(d, all.filter((t) => t.direction === d));
  console.log("\nBy exit:");
  for (const e of ["SL", "BE", "TP3", "TIMEOUT"]) line(e, all.filter((t) => t.exit === e));

  const csv = ["symbol,direction,openedAt,closedAt,entry,score,exit,netR", ...all.map((t) =>
    [t.symbol, t.direction, new Date(t.openedAt).toISOString(), new Date(t.closedAt).toISOString(), t.entry, t.score, t.exit, t.r.toFixed(3)].join(","))].join("\n");
  writeFileSync("backtest-trades.csv", csv);
  console.log("\nSaved backtest-trades.csv. Judge the OUT-OF-SAMPLE line, not ALL.");
  console.log("Past results do not guarantee future performance.");
}

void main();
