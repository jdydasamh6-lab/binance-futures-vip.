import app from "./app";
import { logger } from "./lib/logger";
import { getSettings } from "./lib/trading-store";
import { refreshActiveSignals, runAutomaticMarketScan } from "./routes/trading";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  const fallbackIntervalMs = Number(process.env["BOT_SCAN_INTERVAL_MS"] ?? 300_000);

  const scheduleAutomaticScan = async () => {
    try {
      await runAutomaticMarketScan();
    } catch (scanError) {
      logger.warn({ err: scanError }, "Automatic Futures scan failed");
    }

    let nextIntervalMs = fallbackIntervalMs;
    try {
      nextIntervalMs = (await getSettings()).scanIntervalMs;
    } catch (settingsError) {
      logger.warn({ err: settingsError }, "Could not read scan interval");
    }
    logger.info({ intervalMs: nextIntervalMs }, "Next Futures scan scheduled");
    setTimeout(() => {
      void scheduleAutomaticScan();
    }, Math.max(30_000, nextIntervalMs));
  };

  logger.info({ intervalMs: fallbackIntervalMs }, "Automatic Futures scan scheduled");
  setTimeout(() => {
    void scheduleAutomaticScan();
  }, 10_000);

  setInterval(() => {
    void refreshActiveSignals().catch((monitorError) => {
      logger.warn({ err: monitorError }, "Active signal monitor failed");
    });
  }, 60_000);
});
