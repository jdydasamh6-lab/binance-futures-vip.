/**
 * Backtest — uses the exact same strategy code as the live bot.
 *
 * Run (Node 22+):
 *   node --experimental-strip-types scripts/backtest.ts --months 12
 *   node --experimental-strip-types scripts/backtest.ts --months 6 --symbols BTCUSDT,ETHUSDT,SOLUSDT
 *   node --experimental-strip-types scripts/backtest.ts --synthetic     (offline self-test, fake data)
 *
 * Output: console summary + backtest-out/trades.csv. Downloaded candles are cached in
 * backtest-out/cache so re-runs are fast.
 *
 * Realism: signals only on CLOSED candles, entry = signal close, fees + slippage charged,
 * stop wins when stop and target are touched in the same candle, daily cap and max
 * concurrent trades applied exactly like the live bot.
 */
import { mkdirSync, existsSync, readFileSync, writeFileSync } from "node:fs";
import {
  DEFAULT_CONFIG,
  evaluate,
  netR,
  newTrade,
  stepTrade,
  type Candle,
  type Setup,
} from "../src/lib/strategy.ts";
import { computeStats, type ClosedResult } from "../src/lib/stats.ts";

const BASE = "https://fapi.binance.com";
const OUT = "backtest-out";
const MIN15 = 15 * 60_000;

const args = process.argv.slice(2);
const arg = (name: string, fallback?: string) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? (args[i + 1] ?? "true") : fallback;
};
const months = Number(arg("months", "12"));
const synthetic = args.includes("--synthetic");
const maxPerDay = Number(arg("max-per-day", "5"));
const maxConcurrent = Number(arg("max-concurrent", "3"));
const cfg = { ...DEFAULT_CONFIG, minScore: Number(arg("min-score", String(DEFAULT_CONFIG.minScore))) };
const symbols = (
  arg(
    "symbols",
    "BTCUSDT,ETHUSDT,BNBUSDT,SOLUSDT,XRPUSDT,DOGEUSDT,ADAUSDT,AVAXUSDT,LINKUSDT,LTCUSDT,SUIUSDT,NEARUSDT,DOTUSDT,AAVEUSDT,APTUSDT",
  ) as string
).split(",");

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function getJson(path: string, params: Record<string, string | number>) {
  const url = `${BASE}${path}?${new URLSearchParams(Object.entries(params).map(([k, v]) => [k, String(v)]))}`;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const res = await fetch(url);
    if (res.ok) return res.json();
    if (res.status === 429 || res.status === 418) await sleep(5_000 * (attempt + 1));
    else if (attempt === 4) throw new Error(`${res.status} ${url}`);
    else await sleep(1_000);
  }
  throw new Error(`failed ${url}`);
}

function toCandle(row: unknown[]): Candle {
  return {
    openTime: Number(row[0]),
    open: Number(row[1]),
    high: Number(row[2]),
    low: Number(row[3]),
    close: Number(row[4]),
    volume: Number(row[5]),
    closeTime: Number(row[6]),
    quoteVolume: Number(row[7]),
  };
}

async function fetchKlines(symbol: string, interval: string, startTime: number, endTime: number): Promise<Candle[]> {
  const cacheFile = `${OUT}/cache/${symbol}_${interval}_${months}m_${new Date(endTime).toISOString().slice(0, 10)}.json`;
  if (existsSync(cacheFile)) return JSON.parse(readFileSync(cacheFile, "utf8"));
  const all: Candle[] = [];
  let cursor = startTime;
  while (cursor < endTime) {
    const rows = (await getJson("/fapi/v1/klines", { symbol, interval, startTime: cursor, limit: 1500 })) as unknown[][];
    if (!rows.length) break;
    for (const row of rows) all.push(toCandle(row));
    cursor = Number(rows[rows.length - 1][0]) + 1;
    await sleep(120);
  }
  const closed = all.filter((c) => c.closeTime < endTime);
  writeFileSync(cacheFile, JSON.stringify(closed));
  return closed;
}

async function fetchFunding(symbol: string, startTime: number, endTime: number): Promise<Array<{ t: number; rate: number }>> {
  const cacheFile = `${OUT}/cache/${symbol}_funding_${months}m_${new Date(endTime).toISOString().slice(0, 10)}.json`;
  if (existsSync(cacheFile)) return JSON.parse(readFileSync(cacheFile, "utf8"));
  const all: Array<{ t: number; rate: number }> = [];
  let cursor = startTime;
  while (cursor < endTime) {
    const rows = (await getJson("/fapi/v1/fundingRate", { symbol, startTime: cursor, limit: 1000 })) as Array<{
      fundingTime: number;
      fundingRate: string;
    }>;
    if (!rows.length) break;
    for (const r of rows) all.push({ t: r.fundingTime, rate: Number(r.fundingRate) });
    cursor = rows[rows.length - 1].fundingTime + 1;
    await sleep(120);
  }
  writeFileSync(cacheFile, JSON.stringify(all));
  return all;
}

// ---- synthetic data (offline self-test only; results are meaningless) ----
function syntheticCandles(seed: number, n15: number, start: number) {
  let s = seed;
  const rnd = () => ((s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296);
  const c15: Candle[] = [];
  let price = 100 + seed;
  let drift = 0;
  for (let i = 0; i < n15; i += 1) {
    if (i % 400 === 0) drift = (rnd() - 0.5) * 0.002;
    const open = price;
    const close = open * (1 + drift + (rnd() - 0.5) * 0.006);
    const high = Math.max(open, close) * (1 + rnd() * 0.002);
    const low = Math.min(open, close) * (1 - rnd() * 0.002);
    const vol = 1_000_000 * (0.5 + rnd() * 1.5);
    const openTime = start + i * MIN15;
    c15.push({ openTime, closeTime: openTime + MIN15 - 1, open, high, low, close, volume: vol, quoteVolume: vol * close });
    price = close;
  }
  return c15;
}

function aggregate(c15: Candle[], factor: number): Candle[] {
  const out: Candle[] = [];
  for (let i = 0; i + factor <= c15.length; i += factor) {
    const g = c15.slice(i, i + factor);
    out.push({
      openTime: g[0].openTime,
      closeTime: g[g.length - 1].closeTime,
      open: g[0].open,
      high: Math.max(...g.map((c) => c.high)),
      low: Math.min(...g.map((c) => c.low)),
      close: g[g.length - 1].close,
      volume: g.reduce((a, c) => a + c.volume, 0),
      quoteVolume: g.reduce((a, c) => a + c.quoteVolume, 0),
    });
  }
  return out;
}

type Trade = {
  symbol: string;
  direction: string;
  entryTime: number;
  exitTime: number;
  entry: number;
  score: number;
  exitReason: string;
  r: number;
};

type SymbolData = { c15: Candle[]; c1h: Candle[]; c4h: Candle[]; funding: Array<{ t: number; rate: number }> };

function runSymbol(symbol: string, d: SymbolData, btc1h: Candle[], rejects: Map<string, number>): Trade[] {
  const trades: Trade[] = [];
  let i1 = 0;
  let i4 = 0;
  let ib = 0;
  let fi = 0;
  let busyUntil = -1;
  let cooldownUntil = -1;
  for (let i = 120; i < d.c15.length; i += 1) {
    const t = d.c15[i].closeTime;
    while (i1 + 1 < d.c1h.length && d.c1h[i1 + 1].closeTime <= t) i1 += 1;
    while (i4 + 1 < d.c4h.length && d.c4h[i4 + 1].closeTime <= t) i4 += 1;
    while (ib + 1 < btc1h.length && btc1h[ib + 1].closeTime <= t) ib += 1;
    while (fi + 1 < d.funding.length && d.funding[fi + 1].t <= t) fi += 1;
    if (t <= busyUntil || t <= cooldownUntil) continue;
    if (d.c1h[i1].closeTime > t || d.c4h[i4].closeTime > t) continue;
    const res = evaluate({
      symbol,
      c15: d.c15.slice(i - 119, i + 1),
      c1h: d.c1h.slice(Math.max(0, i1 - 119), i1 + 1),
      c4h: d.c4h.slice(Math.max(0, i4 - 119), i4 + 1),
      btc1h: btc1h.slice(Math.max(0, ib - 119), ib + 1),
      funding: d.funding.length && d.funding[fi].t <= t ? d.funding[fi].rate : undefined,
      cfg,
    });
    if (!res.ok) {
      rejects.set(res.reason, (rejects.get(res.reason) ?? 0) + 1);
      continue;
    }
    const setup: Setup = res.setup;
    let state = newTrade(setup);
    let j = i + 1;
    let exitTime = t;
    for (; j < d.c15.length && !state.closed; j += 1) {
      state = stepTrade(state, d.c15[j], cfg).state;
      exitTime = d.c15[j].closeTime;
    }
    if (!state.closed) break; // data ended mid-trade, discard
    trades.push({
      symbol,
      direction: setup.direction,
      entryTime: t,
      exitTime,
      entry: setup.entry,
      score: setup.score,
      exitReason: state.exitReason ?? "?",
      r: netR(state, setup.costR),
    });
    busyUntil = exitTime;
    cooldownUntil = exitTime + 2 * 3_600_000; // 2h cooldown after a trade on the same symbol
  }
  return trades;
}

function applyPortfolioRules(all: Trade[]): Trade[] {
  const sorted = [...all].sort((a, b) => a.entryTime - b.entryTime);
  const perDay = new Map<string, number>();
  const open: Trade[] = [];
  const kept: Trade[] = [];
  for (const tr of sorted) {
    const day = new Date(tr.entryTime).toISOString().slice(0, 10);
    for (let k = open.length - 1; k >= 0; k -= 1) if (open[k].exitTime <= tr.entryTime) open.splice(k, 1);
    if ((perDay.get(day) ?? 0) >= maxPerDay) continue;
    if (open.length >= maxConcurrent) continue;
    perDay.set(day, (perDay.get(day) ?? 0) + 1);
    open.push(tr);
    kept.push(tr);
  }
  return kept;
}

function fmt(label: string, results: ClosedResult[]) {
  const s = computeStats(results);
  console.log(
    `${label.padEnd(22)} n=${String(s.trades).padStart(4)}  win=${String(s.winRate).padStart(5)}%  avgR=${String(s.avgR).padStart(5)}  PF=${String(s.profitFactor ?? "∞").padStart(5)}  totalR=${String(s.totalR).padStart(7)}  maxDD=${s.maxDrawdownR}R`,
  );
}

async function main() {
  mkdirSync(`${OUT}/cache`, { recursive: true });
  const end = Date.now();
  const start = end - months * 30 * 24 * 3_600_000;
  const data = new Map<string, SymbolData>();
  const list = Array.from(new Set(["BTCUSDT", ...symbols]));

  if (synthetic) {
    const n = months * 30 * 96;
    const s0 = end - n * MIN15;
    list.forEach((sym, k) => {
      const c15 = syntheticCandles(k + 7, n, s0);
      data.set(sym, { c15, c1h: aggregate(c15, 4), c4h: aggregate(c15, 16), funding: [] });
    });
    console.log("SYNTHETIC mode: numbers below are meaningless, this only tests the pipeline.\n");
  } else {
    for (const sym of list) {
      process.stdout.write(`downloading ${sym} ... `);
      const [c15, c1h, c4h, funding] = await Promise.all([
        fetchKlines(sym, "15m", start, end),
        fetchKlines(sym, "1h", start - 10 * 24 * 3_600_000, end),
        fetchKlines(sym, "4h", start - 30 * 24 * 3_600_000, end),
        fetchFunding(sym, start, end),
      ]);
      data.set(sym, { c15, c1h, c4h, funding });
      console.log(`${c15.length} candles`);
    }
  }

  const btc1h = data.get("BTCUSDT")!.c1h;
  const rejects = new Map<string, number>();
  let raw: Trade[] = [];
  for (const sym of list) {
    if (!symbols.includes(sym) && sym === "BTCUSDT" && !symbols.includes("BTCUSDT")) continue;
    raw = raw.concat(runSymbol(sym, data.get(sym)!, btc1h, rejects));
  }
  const trades = applyPortfolioRules(raw);
  const results: ClosedResult[] = trades.map((t) => ({ r: t.r, closedAt: t.exitTime }));

  console.log(`\n=== Backtest ${months} months · ${list.length} symbols · cap ${maxPerDay}/day · max ${maxConcurrent} concurrent ===`);
  console.log(`costs: fee ${DEFAULT_CONFIG.feeRatePerSide * 100}%/side + slippage ${DEFAULT_CONFIG.slippagePerSide * 100}%/side, already inside R\n`);
  fmt("ALL", results);
  const cut = start + (end - start) * (2 / 3);
  fmt("in-sample (first 2/3)", results.filter((r) => r.closedAt < cut));
  fmt("out-of-sample (last 1/3)", results.filter((r) => r.closedAt >= cut));
  console.log("\nBy direction:");
  for (const d of ["LONG", "SHORT"]) fmt(d, trades.filter((t) => t.direction === d).map((t) => ({ r: t.r, closedAt: t.exitTime })));
  console.log("\nBy exit:");
  for (const e of ["SL", "BE", "TP3", "TIMEOUT"]) fmt(e, trades.filter((t) => t.exitReason === e).map((t) => ({ r: t.r, closedAt: t.exitTime })));
  console.log("\nBy symbol:");
  for (const sym of list) fmt(sym, trades.filter((t) => t.symbol === sym).map((t) => ({ r: t.r, closedAt: t.exitTime })));
  console.log("\nBy month:");
  const months2 = Array.from(new Set(trades.map((t) => new Date(t.exitTime).toISOString().slice(0, 7)))).sort();
  for (const m of months2) fmt(m, trades.filter((t) => new Date(t.exitTime).toISOString().slice(0, 7) === m).map((t) => ({ r: t.r, closedAt: t.exitTime })));
  console.log("\nTop rejection reasons (candles):");
  [...rejects.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).forEach(([k, v]) => console.log(`  ${k.padEnd(24)} ${v}`));

  const csv = ["symbol,direction,entryTime,exitTime,entry,score,exitReason,netR"]
    .concat(trades.map((t) => [t.symbol, t.direction, new Date(t.entryTime).toISOString(), new Date(t.exitTime).toISOString(), t.entry, t.score, t.exitReason, t.r.toFixed(3)].join(",")))
    .join("\n");
  writeFileSync(`${OUT}/trades.csv`, csv);
  console.log(`\nSaved ${trades.length} trades to ${OUT}/trades.csv`);
  console.log("Reminder: a good backtest is necessary, not sufficient. Forward-test before trusting it.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
