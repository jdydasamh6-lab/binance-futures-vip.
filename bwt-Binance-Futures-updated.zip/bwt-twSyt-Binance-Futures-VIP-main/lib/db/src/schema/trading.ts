import { createInsertSchema } from "drizzle-zod";
import {
  bigint,
  boolean,
  doublePrecision,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const botSettingsTable = pgTable("bot_settings", {
  id: integer("id").primaryKey().default(1),
  scanIntervalMs: integer("scan_interval_ms").notNull().default(300_000),
  minConfidence: integer("min_confidence").notNull().default(80),
  defaultLeverage: text("default_leverage").notNull().default("10x - 20x"),
  autoBreakEven: boolean("auto_break_even").notNull().default(true),
  telegramStatus: text("telegram_status").notNull().default("غير متصل"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const tradingSignalsTable = pgTable("trading_signals", {
  id: text("id").primaryKey(),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(),
  entryPrice: doublePrecision("entry_price").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  leverage: text("leverage").notNull(),
  confidence: integer("confidence").notNull(),
  reason: text("reason").notNull(),
  timeframe: text("timeframe").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  status: text("status").notNull().default("نشطة"),
  tp1Price: doublePrecision("tp1_price").notNull(),
  tp1Percent: integer("tp1_percent").notNull().default(35),
  tp1Status: text("tp1_status").notNull().default("قيد المراقبة"),
  tp2Price: doublePrecision("tp2_price").notNull(),
  tp2Percent: integer("tp2_percent").notNull().default(35),
  tp2Status: text("tp2_status").notNull().default("قيد المراقبة"),
  tp3Price: doublePrecision("tp3_price").notNull(),
  tp3Percent: integer("tp3_percent").notNull().default(30),
  tp3Status: text("tp3_status").notNull().default("قيد المراقبة"),
  breakEvenMoved: boolean("break_even_moved").notNull().default(false),
  currentPrice: doublePrecision("current_price"),
  closedAt: timestamp("closed_at", { withTimezone: true }),
  // --- performance tracking (nullable: older rows have no R data) ---
  riskDistance: doublePrecision("risk_distance"),
  initialStop: doublePrecision("initial_stop"),
  costR: doublePrecision("cost_r").notNull().default(0),
  realizedR: doublePrecision("realized_r").notNull().default(0),
  remaining: doublePrecision("remaining").notNull().default(1),
  resultR: doublePrecision("result_r"), // net R after fees, set when closed
  exitReason: text("exit_reason"),
  signalCandleTime: bigint("signal_candle_time", { mode: "number" }),
  lastCandleTime: bigint("last_candle_time", { mode: "number" }),
});

export const signalTargetsTable = pgTable("signal_targets", {
  id: serial("id").primaryKey(),
  signalId: text("signal_id").notNull(),
  label: text("label").notNull(),
  price: doublePrecision("price").notNull(),
  percent: integer("percent").notNull(),
  status: text("status").notNull().default("قيد المراقبة"),
  sortOrder: integer("sort_order").notNull(),
});

export const alertEventsTable = pgTable("alert_events", {
  id: text("id").primaryKey(),
  signalId: text("signal_id"),
  type: text("type").notNull(),
  title: text("title").notNull(),
  detail: text("detail").notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
  status: text("status").notNull(),
  attempts: integer("attempts").notNull().default(1),
  sentAt: timestamp("sent_at", { withTimezone: true }),
});

export const insertBotSettingsSchema = createInsertSchema(botSettingsTable).omit({
  updatedAt: true,
});
export const insertTradingSignalSchema = createInsertSchema(tradingSignalsTable).omit({
  createdAt: true,
  closedAt: true,
});
export const insertSignalTargetSchema = createInsertSchema(signalTargetsTable).omit({
  id: true,
});
export const insertAlertEventSchema = createInsertSchema(alertEventsTable).omit({
  timestamp: true,
});

export type InsertBotSettings = z.infer<typeof insertBotSettingsSchema>;
export type BotSettings = typeof botSettingsTable.$inferSelect;
export type InsertTradingSignal = z.infer<typeof insertTradingSignalSchema>;
export type TradingSignal = typeof tradingSignalsTable.$inferSelect;
export type InsertSignalTarget = z.infer<typeof insertSignalTargetSchema>;
export type SignalTarget = typeof signalTargetsTable.$inferSelect;
export type InsertAlertEvent = z.infer<typeof insertAlertEventSchema>;
export type AlertEvent = typeof alertEventsTable.$inferSelect;